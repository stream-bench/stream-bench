streambench \
    --agent_cfg "configs/agent/ablations/gpic/spider.yml" \
    --bench_cfg "configs/bench/spider.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/gpic/cosql.yml" \
    --bench_cfg "configs/bench/cosql.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/gpic/bird.yml" \
    --bench_cfg "configs/bench/bird.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/gpic/ddxplus.yml" \
    --bench_cfg "configs/bench/ddxplus.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/gpic/hotpotqa_distract.yml" \
    --bench_cfg "configs/bench/hotpotqa_distract.yml" \
    --entity "photocopier" \
    --use_wandb
