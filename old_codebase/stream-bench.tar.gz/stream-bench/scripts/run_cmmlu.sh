# # zero-shot
# streambench \
#     --agent_cfg "configs/agent/zeroshot.yml" \
#     --bench_cfg "configs/bench/cmmlu.yml" \
#     --entity "photocopier" \
#     --name "ZeroShotAgent__anthropic__claude-3-haiku-20240307__zhinstmulti" \
#     --use_wandb

# # few-shot
# streambench \
#     --agent_cfg "configs/agent/fewshot.yml" \
#     --bench_cfg "configs/bench/cmmlu.yml" \
#     --use_wandb \

# # chain of thought
# streambench \
#     --agent_cfg "configs/agent/cot.yml" \
#     --bench_cfg "configs/bench/cmmlu.yml" \
#     --use_wandb
