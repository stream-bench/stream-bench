seeds=(2 3 7 21)
for seed in "${seeds[@]}"
do
    python -m stream_bench.pipelines.run_bench_multiple_seeds \
        --agent_cfg "configs/agent/gt_correctness_self_fewshot_rag_temp.yml" \
        --bench_cfg "configs/bench/ddxplus.yml" \
        --entity "photocopier" \
        --seed $seed \
        --use_wandb
done