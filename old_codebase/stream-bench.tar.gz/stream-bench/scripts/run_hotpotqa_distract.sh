streambench \
    --agent_cfg "configs/agent/mem_prompt_temp.yml" \
    --bench_cfg "configs/bench/hotpotqa_distract.yml" \
    --entity "photocopier" \
    --use_wandb
