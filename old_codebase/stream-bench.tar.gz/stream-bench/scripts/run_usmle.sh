# # zero-shot
# streambench \
#     --agent_cfg "configs/agent/zeroshot.yml" \
#     --bench_cfg "configs/bench/medqa_usmle.yml" \
#     --entity "photocopier" \
#     --use_wandb

# # few-shot
# streambench \
#     --agent_cfg "configs/agent/fewshot.yml" \
#     --bench_cfg "configs/bench/medqa_usmle.yml" \
#     --entity "photocopier" \
#     --use_wandb

# # chain of thought
# streambench \
#     --agent_cfg "configs/agent/cot.yml" \
#     --bench_cfg "configs/bench/medqa_usmle.yml" \
#     --use_wandb

# # self all few-shot RAG
# streambench \
#     --agent_cfg "configs/agent/self_all_fewshot_rag.yml" \
#     --bench_cfg "configs/bench/medqa_usmle.yml" \
#     --use_wandb

# # ground-truth few-shot RAG
# streambench \
#     --agent_cfg "configs/agent/gt_fewshot_rag.yml" \
#     --bench_cfg "configs/bench/medqa_usmle.yml" \
#     --entity "photocopier" \
#     --use_wandb
