streambench \
    --agent_cfg "configs/agent/zeroshot.yml" \
    --bench_cfg "configs/bench/spider.yml" \
    --entity "photocopier" \
    --use_wandb
