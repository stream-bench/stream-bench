streambench \
    --agent_cfg "configs/agent/ablations/mpc/spider.yml" \
    --bench_cfg "configs/bench/spider.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/mpc/cosql.yml" \
    --bench_cfg "configs/bench/cosql.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/mpc/bird.yml" \
    --bench_cfg "configs/bench/bird.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/mpc/ddxplus.yml" \
    --bench_cfg "configs/bench/ddxplus.yml" \
    --entity "photocopier" \
    --use_wandb

streambench \
    --agent_cfg "configs/agent/ablations/mpc/hotpotqa_distract.yml" \
    --bench_cfg "configs/bench/hotpotqa_distract.yml" \
    --entity "photocopier" \
    --use_wandb
