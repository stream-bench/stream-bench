streambench \
    --agent_cfg "configs/agent/fewshot.yml" \
    --bench_cfg "configs/bench/toolbench.yml" \
    --entity "photocopier" \
    --use_wandb
