streambench \
    --agent_cfg "configs/agent/zeroshot.yml" \
    --bench_cfg "configs/bench/cosql.yml" \
    --entity "photocopier" \
    --use_wandb
