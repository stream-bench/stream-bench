streambench \
    --agent_cfg "configs/agent/multiagent_rag.yml" \
    --bench_cfg "configs/bench/ddxplus.yml" \
    --entity "photocopier" \
    --use_wandb
