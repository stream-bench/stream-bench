# # zero-shot
# streambench \
#     --agent_cfg "configs/agent/zeroshot.yml" \
#     --bench_cfg "configs/bench/mmlu.yml" \
#     --use_wandb

# # few-shot
# streambench \
#     --agent_cfg "configs/agent/fewshot.yml" \
#     --bench_cfg "configs/bench/mmlu.yml" \
#     --use_wandb

# # chain of thought
# streambench \
#     --agent_cfg "configs/agent/cot.yml" \
#     --bench_cfg "configs/bench/mmlu.yml" \
#     --use_wandb
