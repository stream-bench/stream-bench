streambench \
    --agent_cfg "configs/agent/zeroshot.yml" \
    --bench_cfg "configs/bench/bird.yml" \
    --entity "photocopier" \
    --use_wandb
