import json
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import entropy
from scipy.special import softmax
from pathlib import Path
from argparse import ArgumentParser, Namespace

LABEL_SET = ['A', 'B', 'C', 'D']

# Load the jsonl file
def load_jsonl(file_path):
    with open(file_path, 'r') as file:
        data = [json.loads(line) for line in file]
    return data

def extract_logits(row: dict) -> np.ndarray:
    logits = list()
    # preprocessing
    token2logits = dict()
    for logit_d in row["logprobs_pred"][0]:
        token2logits[logit_d["token"]] = logit_d["logprob"]
    for label in LABEL_SET:
        logit = token2logits.get(label, float("-inf"))
        logits.append(logit)
    return np.array(logits)

def calc_entropy(logits: np.ndarray) -> float:
    probs = softmax(logits)
    return entropy(probs)

# Calculate entropy for each instance
def calculate_entropy(data):
    entropies = []
    for instance in data:
        logits = extract_logits(instance)
        H = calc_entropy(logits)
        entropies.append(H)
    return entropies

# Main function to plot the curve
def plot_accuracy_curve(data: list[dict], n_points: int = 100):
    entropies = calculate_entropy(data)
    correct = [int(row["output_pred"][0] == row["label_text"]) for row in data]  # NOTE: current only consider MCQs, so [0] is sufficient
    tuples = sorted(list(zip(correct, entropies)), key=lambda t: t[1], reverse=True)
    correct_count = [is_correct for is_correct, _ in tuples]  # NOTE: instances from high-entropy to low-entropy
    for i in range(-2, -len(correct_count) - 1, -1):
        correct_count[i] += correct_count[i + 1]
    # Initialize lists for plotting
    filtered_ratios = list()
    accuracies = list()
    
    # Calculate the accuracy at each entropy threshold
    for i in range(len(tuples)):
        # Calculate filtered ratio
        filtered_ratio = i / len(tuples) * 100
        # Calculate accuracy up to the current index
        accuracy = correct_count[i] / (len(tuples) - i)
        filtered_ratios.append(filtered_ratio)
        accuracies.append(accuracy)

    n_points = min(n_points, len(tuples))
    ratios_plot = [(i / n_points * 100) for i in range(n_points)]
    accs_plot = [accuracies[int(i / n_points * len(tuples))] for i in range(n_points)]
    # Plot the curve
    plt.plot(ratios_plot, accs_plot, '-o', label='Entropy')
    plt.xlabel('Filtered Out (%)')
    plt.ylabel('Accuracy')
    plt.title('Accuracy vs Filtered Ratio')
    plt.legend()
    plt.show()

def setup_args() -> Namespace:
    parser = ArgumentParser()
    parser.add_argument(
        "--jsonl",
        type=Path,
        required=True
    )
    parser.add_argument(
        "--n_points",
        type=int,
        default=int(1e8)
    )
    return parser.parse_args()

if __name__ == "__main__":
    args = setup_args()
    data = load_jsonl(args.jsonl)
    plot_accuracy_curve(data, args.n_points)
