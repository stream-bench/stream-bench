# Stream Bench

```
pip install -e .
```

```
streambench --agent_cfg configs/agent/baseline.yml --bench_cfg configs/bench/humaneval.yml --use_wandb --entity appier-ai-research --project streambench-humaneval
```

```
streambench --agent_cfg configs/agent/baseline.yml --bench_cfg configs/bench/anli.yml --use_wandb --entity appier-ai-research --project streambench-anli          
```


Make sure you have these environment variable added:

```
GOOGLE_API_KEY="google studio api key"
ANTHROPIC_KEY="anthropic key"
OAI_KEY="open ai key"
CUSTOM_API_URL="if you use openai custom backend api set this variable"
HF_ALLOW_CODE_EVAL=1 # for humaneval code execution
```

## Architecture outline

**Agent**

where pipeline implementations goes : retrieval feedback, feedback insertion, multi agent etc

agent config goes here, make sure it supports all kinds of LLMs call

**Benchmark**

dataset, initial prompting, response validation (check correct or not correct), parse response from agent reply etc


**LLMs**

basically just a class where different LLMs interface are implemented.


## Task Description

Each task are formulated under streaming

## TODO

[] - do we want to unify each steps for each pipeline?

[] - Make experiment params into yaml config method

    openai_humaneval_streaming.yml
    ```yaml
    task: humaneval
    pipeline:
        - retrieval
        - reflection
        - answer
        - reflection
        - decide_save:
            true:
                ??
            false: 
                ??
    rag_embedding: BAAI/bge-base-en-v1.5
    retrieve_top: 30
    llm_series: openai
    model_name: gpt-3.5-turbo-0613
    ```

    ```python
    python eval --cfg openai_humaneval_streaming.yml
    ```

    [] - need to rewrite text-to-sql to support the above yaml first

[] - make `humaneval`, `MMLU`, ... to support yaml format

- @ray.tam : `humaneval`

