from .base import Agent
from .utils import text_in_label_set, parse_pred_text

class FewShotIncrementAgent(Agent):
    LOG_KEYS_FOR_PROMPT = [
        "input_pred",
        "output_pred",
        "logprobs_pred",
        "input_parse",
        "output_parse",
        "logprobs_parse"
    ]

    def __init__(self, config: dict) -> None:
        self.config = config
        self.series = self.config["llm"]["series"]
        self.model_name = self.config["llm"]["model_name"]
        self.top_k = int(self.config['rag']['top_k'])
        super().__init__(config)
        self.past_fewshots = []

    def create_fewshot(self):
        few_shots = ''
        latest_examples = self.past_fewshots[-self.top_k:]
        for row in latest_examples:
            question = self.bench.get_question_text(row)
            answer = self.bench.get_answer_text(row)
            if '{choices}' in self.bench.SHOT_TEMPLATE:
                choices = self.bench.get_choices_text(row)
                shot = self.bench.SHOT_TEMPLATE.format(question=question, choices=choices, answer=answer)
            else:
                shot = self.bench.SHOT_TEMPLATE.format(question=question, answer=answer)
            few_shots += shot + '\n\n'
        return few_shots

    def __call__(self, prompt: str=None, prompt_zeroshot: str=None, **kwargs) -> str:
        # Initialize variable for tracking
        self.reset_log_info()
        fewshot_text = self.create_fewshot()
        question = self.bench.get_question_text(kwargs)
        choices = self.bench.get_choices_text(kwargs)
        prompt_fewshot = self.bench.FEWSHOT_TEMPLATE.format(
                    question=question, choices=choices
                )
        prompt_fewshot = prompt_fewshot.replace('{fewshot_text}', fewshot_text)

        # Inference
        pred_text, pred_info = self.llm(prompt=prompt_fewshot,
                                        max_tokens=self.llm_config["max_tokens"],
                                        temperature=self.llm_config["temperature"]
                                    )
        # logging
        self.update_log_info(log_data={
            "input_pred": prompt_fewshot,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })

        return pred_text

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        self.past_fewshots.append(feedbacks)
        return True

    def get_name(self):
        return 'increment-fewshot-{}-{}-{}'.format(self.series, self.top_k, self.model_name)
