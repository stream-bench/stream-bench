"""
    DEPRECATED
"""
import os
import google.generativeai as genai
from .utils import retry_with_exponential_backoff

class GeminiDev:
    SAFETY_SETTINGS=[
        {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
        {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
    ]

    def __init__(self, model_name: str = "gemini-1.0-pro") -> None:
        genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
        self.model = genai.GenerativeModel(model_name)

    @retry_with_exponential_backoff
    def __call__(self, prompt: str, max_tokens=512, temperature=0.0) -> str:
        res = self.model.generate_content(
            prompt,
            generation_config={
                "max_output_tokens": max_tokens,
                "temperature": temperature
            },
            safety_settings=self.SAFETY_SETTINGS,
            stream=False
        )
        return res.text