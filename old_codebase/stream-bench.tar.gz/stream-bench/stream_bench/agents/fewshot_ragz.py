import textwrap
from enum import Enum
from tqdm import tqdm

from stream_bench.agents.base import Agent
from stream_bench.agents.utils import RAG, parse_pred_text, text_in_label_set

class Method(Enum):
    RATIONALE_ALL = "ragz_rationale_all"
    RATIONALE_GT = "ragz_rationale_gt"
    RATIONALE_ORACLE_GT = "ragz_rationale_oracle_gt"
    RATIONALE_ORACLE_GT_NS = "ragz_rationale_oracle_gt_no_stream"

class FewShotRAGZAgent(Agent):
    METHODS = {member.value for member in Method}
    # Prompt for extracting the rationale
    PROMPT_RATIONALE = textwrap.dedent(f"""\
    {{desc}}

    {{x}}
    Answer (generate the rationale before providing the final answer):""")
    # PROMPT_PARSE (in the base class)
    # Prompt for extracting the rationale (with oracle label)
    PROMPT_RATIONALE_ORACLE = textwrap.dedent(f"""\
    {{desc}}
    
    {{x}}
    Answer: {{y}}

    Based on the information above, generate the rationale that leads to the provided answer '{{y}}':""")
    # Rationale template (value) to be saved in the RAG pool (Note: the key embedding should only use x or desc + x)
    RATIONALE_TEMPLATE = textwrap.dedent(f"""\
    {{x}}
    Rationale: {{z}}
    Answer: {{y}}""")
    # Few-shot template
    PROMPT_FEWSHOT_RATIONALE = textwrap.dedent(f"""\
    {{desc}}
    
    Here are some example cases.
    
    {{fewshot_text}}
    
    Now answer the following case.
    
    {{x}}
    Rationale:""")
    SHOT_DELIMITER = "\n\n\n"

    def __init__(self, config: dict) -> None:
        assert config["agent_name"] in self.METHODS
        super().__init__(config)
        self.method = config["agent_name"]
        if config["rag"]["rag_filename"] is None:
            config["rag"]["rag_filename"] = self.log_path + ".db"
        self.rag = RAG(config["rag"])    

    def __call__(
        self,
        desc: str,
        x: str,
        label_set: set[str],
        **kwargs
    ) -> str:
        # Retrieve few-shot examples
        shots = self.rag.retrieve(query=x, top_k=self.rag.top_k) if (self.rag.insert_acc > 0) else []  # seems redundant but to ensure flexibility of .retrieve()
        if len(shots):
            fewshot_text = self.SHOT_DELIMITER.join(shots)
            if self.method in {Method.RATIONALE_ORACLE_GT.value, Method.RATIONALE_ORACLE_GT_NS.value}:
                try:
                    prompt = self.PROMPT_FEWSHOT_RATIONALE.format(desc=desc, fewshot_text=fewshot_text, x=x)
                except KeyError:
                    error_msg = f"Error caused by these shots. Logged to jsonl."
                    print(error_msg)
                    shots.append(error_msg)  # For analyzing errors afterwards
                    prompt = self.PROMPT_RATIONALE.format(desc=desc, x=x)
            else:
                raise NotImplementedError
        else:  # NOTE: not supposed to happen in this version
            raise NotImplementedError
        # Inference
        pred_text, pred_info = self.llm(prompt=prompt, max_tokens=self.llm_config["max_tokens"], temperature=self.llm_config["temperature"])
        # logging
        self.update_log_info(log_data={
            "retrieved_shots": shots,
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        # (Optional) Parse pred_text into one of the labels in label_set
        pred_text = parse_pred_text(pred_text, label_set)  # simple heuristics for removing leading and trailing characters
        if not text_in_label_set(text=pred_text, label_set=label_set):
            prompt_parse = self.PROMPT_PARSE.format(model_output=pred_text, options=self.get_options_text(label_set))
            parse_text, parse_info = self.llm(prompt=prompt_parse, max_tokens=self.llm_config["max_tokens"], temperature=self.llm_config["temperature"])
            self.update_log_info(log_data={
                "input_parse": prompt_parse,
                "output_parse": parse_text,
                "logprobs_parse": parse_info["logprobs"],
                "num_inference_call": 1,
                "num_success_call": 1 if (parse_text[:5] != "error") else 0,
                "num_input_tokens": parse_info["num_input_tokens"],
                "num_output_tokens": parse_info["num_output_tokens"]
            })
            return parse_text
        return pred_text

    def initialize(self, train_rows: list[dict]) -> None:
        super().initialize(train_rows)
        print("Initializing the RAG pool...")
        for row in tqdm(train_rows):
            # NOTE: now only running PROMPT_RATIONALE_ORACLE
            if self.method in {Method.RATIONALE_ORACLE_GT.value, Method.RATIONALE_ORACLE_GT_NS.value}:
                prompt = self.PROMPT_RATIONALE_ORACLE.format(desc=row["desc"], x=row['x'], y=row['y'])
                z, z_info = self.llm(prompt)
                key = row['x']
                value = self.RATIONALE_TEMPLATE.format(x=row['x'], z=z, y=row['y'])
            else:  # PROMPT_ALL, PROMPT_GT
                # TODO: 
                key = None
                value = None
                raise NotImplementedError
            self.rag.insert(key, value)

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        row = feedbacks
        if self.method == Method.RATIONALE_ORACLE_GT.value:
            prompt = self.PROMPT_RATIONALE_ORACLE.format(desc=row["desc"], x=row['x'], y=row['y'])
            z, z_info = self.llm(prompt)
            key = row['x']
            value = self.RATIONALE_TEMPLATE.format(x=row['x'], z=z, y=row['y'])
        else:
            return False
        self.rag.insert(key, value)
        return True

    def get_name(self) -> str:
        return "__".join([
            self.config["agent_name"],
            self.llm_config["series"],
            self.llm_config["model_name"],
            self.config["rag"]["embedding_model"].split('/')[-1],  # remove '/' to avoid incorrect path
            self.config["rag"]["order"],
            str(self.config["rag"]["top_k"]),
            str(self.config["rag"]["top_n"])
        ])
