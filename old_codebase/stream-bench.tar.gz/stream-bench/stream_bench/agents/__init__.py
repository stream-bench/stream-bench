from .base import Baseline, Agent
from .rag import FeedbackRAG
from .read_agent import ParallelReadAgent
from .rag_w_z import RefinedFeedback
from .rag_w_z_future import RefinedFeedbackFuture
from .scratchpad import MemoryScrubber
from .rag_with_reason import FeedbackReasonRAG
from .reflect_rag import ReflectionFeedbackRAG
from .reflect import Reflection
from .fewshot_increment import FewShotIncrementAgent
from .zeroshot import ZeroShotAgent
from .fewshot import FewShotAgent
from .cot import CoTAgent
from .fewshot_rag import FewShotRAGAgent
try:
    from .webshop import NoStreamingWebAgent, RAGWebAgent, GrowthWebAgent, CoTWebAgent
    has_web = True
except ImportError:
    has_web = False
classes = locals()
from .fewshot_ragz import FewShotRAGZAgent
from .scratchpad import ScratchPadAgent
from .gt import GroundTruthAgent
from .iter_prompt import IterPromptAgent
from .multiagent_rag import MultiAgent

TASKS = {
    'baseline': Baseline,
    'rag_feedback': FeedbackRAG,
    'zeroshot': ZeroShotAgent,
    'fewshot': FewShotAgent,
    'cot': CoTAgent,
    'self_all_fewshot_rag': FewShotRAGAgent,
    'gt_fewshot_rag': FewShotRAGAgent,
    'ragz_rationale_oracle_gt_no_stream': FewShotRAGZAgent,
    'ragz_rationale_oracle_gt': FewShotRAGZAgent,
    'gt_correctness_self_fewshot_rag': FewShotRAGAgent,
    'mem_prompt': FewShotRAGAgent,
    'grow_prompt': ScratchPadAgent,
    'gt': GroundTruthAgent,
    'react': IterPromptAgent,
    'self_refine': IterPromptAgent,
    'react_stream_icl': IterPromptAgent,
    'self_refine_stream_icl': IterPromptAgent,
    'ma_rr': MultiAgent,
    'ma_ts': MultiAgent,
    'ma_dts': MultiAgent
}
if has_web:
    TASKS['web_baseline'] = NoStreamingWebAgent
    TASKS['web_rag'] = RAGWebAgent

def load_agent(agent_name):
    if agent_name in TASKS:
        return TASKS[agent_name]
    if agent_name in classes:
        return classes[agent_name]

    raise ValueError("Agent %s not found" % agent_name)
