import os
import torch
from typing import Any
import textwrap
import numpy as np
from transformers import AutoTokenizer, AutoModel
from localitylens import Pipeline
from .base import Baseline

def extract_retrieve_key(row):
    if 'question' in row and 'db_id' in row:
        return row['question']
    if 'prompt' in row:
        return row['prompt']
    if 'prompt_zeroshot' in row:
        return row['prompt_zeroshot']
    if 'premise' in row:
        return textwrap.dedent(f"""
        Based on the premise and hypothesis provided, determine the relationship between them. Choose the appropriate answer from the following options (one option per line):
        entailment
        neutral
        contradiction

        Premise: {row['premise']}
        Hypothesis: {row['hypothesis']}
        Answer (please only answer with a single word):
        """)
    return ''

class Reflection(Baseline):
    """
        Generic version of RAG agent for long term memory and recall via embedding model
    """
    CRITIC_ANSWER = "Based on this given question and answer, determine whether the answer is correct or not. State your reasons first and then answer it"

    def __init__(self, config: dict) -> None:
        self.config = config
        self.top_k = self.config['rag']['top_k']
        self.reflection_number = int(self.config['reflection_number'])
        self.feedback_kind = self.config['feedback_kind']
        super().__init__(config)
        self.llm_config = config["llm"]
        self.series = self.llm_config["series"]
        self.model_name = self.llm_config["model_name"]
        db_name = self.config['rag']['rag_filename']
        if db_name[-3:] != '.db':
            db_name += '.db'
        if os.path.exists(db_name):
            os.remove(db_name)
        self.insert_acc = 0


    def validate_answer(self, question, answer):
        prompt = self.CRITIC_ANSWER + '\n[Question]'+question + '\n[Answer]\n' + answer
        pred_text, _ = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=0.7
                    )
        return pred_text


    def encode_data(self, sentence):
        # Tokenize sentences
        encoded_input = self.tokenizer([sentence], padding=True, 
                                       truncation=True, 
                                       return_tensors='pt')
        # for s2p(short query to long passage) retrieval task, add an instruction to query (not add instruction for passages)
        # encoded_input = self.tokenizer([instruction + q for q in queries], padding=True, truncation=True, return_tensors='pt')

        # Compute token embeddings
        with torch.no_grad():
            model_output = self.embed_model(**encoded_input)
            # Perform pooling. In this case, cls pooling.
            sentence_embeddings = model_output[0][:, 0]
        feature = sentence_embeddings.numpy()[0]
        norm = np.linalg.norm(feature)
        return feature / norm


    def __call__(self, prompt: str=None, prompt_zeroshot: str=None, **kwargs) -> str:
        self.reset_log_info()
        if prompt is None and prompt_zeroshot is not None:
            prompt = prompt_zeroshot

        time_step = kwargs.pop("time_step")

        reflection_buffer = ''
        for iteration in range(self.reflection_number):
            prompt = textwrap.dedent("""
            You were previously solving a problems. Here is the problem that you were solving:
            [BEGIN PROBLEM]
            {prompt_zeroshot}
            [END PROBLEM]
            {reflection_buffer}
            If the previous attempt is already correct and passed all the tests, then just return the previously solution. Answer the PROBLEM now.
            """).format(prompt_zeroshot=prompt_zeroshot, 
                        reflection_buffer = 'And here are all your past attempts, as well how your answer fared on the unit tests for the problem:\n'+reflection_buffer if len(reflection_buffer) > 0 else ''
                        )
            model_output, _ = self.llm(prompt,
                                max_tokens=self.llm_config["max_tokens"],
                                temperature=self.llm_config["temperature"]
                            )
            reflection_buffer += f'\n Reflection Response Number {iteration+1}:\n Response:\n' + model_output
            if self.feedback_kind == 'system':
                prediction = self.bench.postprocess_generation(model_output, time_step)
                label = self.bench.get_output(kwargs)
                res = self.bench.process_results(
                                        prediction,
                                        label,
                                        return_details=True,
                                        simulate_env=True,
                                        time_step=time_step
                                    )
                exe_result = res['result']
            else:
                exe_result = self.validate_answer(prompt_zeroshot, model_output)
            reflection_buffer += f'\n Reflection Response Execution Output Number {iteration+1}:\n Execute output:\n' + exe_result

        pred_text, pred_info = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        self.update_log_info(log_data={
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        return pred_text

    def get_name(self):
        return 'reflection-{}-{}-{}'.format(self.series, self.reflection_number, self.model_name)

