import re
import random
import numpy as np
from enum import Enum

from stream_bench.agents.base import Agent
from stream_bench.agents.utils import RAG, get_llm, setup_logger
from stream_bench.benchmarks.ddxplus import MedicalDiagnosisBench

class Method(Enum):
    RR = "ma_rr"  # multi-agent round-robin
    TS = "ma_ts"  # multi-agent Thompson sampling
    DTS = "ma_dts"  # multi-agent dynamic Thompson sampling

class MultiAgent(Agent):
    METHODS = {member.value for member in Method}
    C = 100  # a predefined hyperparameter for Dynamic Thompson Sampling

    def __init__(self, config: dict) -> None:
        assert config["agent_name"] in self.METHODS
        self.seed = config["seed"]
        random.seed(self.seed)
        np.random.seed(self.seed)
        self.method = config["agent_name"]
        self.warmup_steps = config["warmup_steps"]  # Use round-robin for the first warmup_steps
        # Originally in super().__init__()
        self.config = config
        self.llms = [get_llm(llm["series"], llm["model_name"]) for llm in config["llms"]]
        self.exp_name = config["exp_name"] if "exp_name" in config else self.get_name()
        self.log_path = f'log/{config["bench_name"]}/{config["split"]}/{self.exp_name}'
        self.logger = setup_logger(name="jsonlines_logger", log_file=f'{self.log_path}.jsonl')
        self.llm_names = [llm["model_name"] for llm in config["llms"]]
        self.LOG_KEYS += [llm["model_name"] for llm in config["llms"]]
        self.log_info = {KEY: 0 for KEY in self.LOG_KEYS}  # log information of the current data point
        self.accum_log_info = {KEY: 0 for KEY in self.LOG_KEYS}  # accum_log_info: accumulation of self.log_info through time steps
        # Initialize information for each agent arm
        self.K = len(self.llms)  # number of agents
        self.S = np.zeros(self.K)  # sum of rewards for each arm
        self.F = np.zeros(self.K)  # sum of (1 - reward)s for each arm
        self.cur_arm = 0
        self.algo_name = self.method.split("_")[-1]
        self.total_steps = 0
        # RAG
        if config["rag"]["rag_filename"] is None:
            config["rag"]["rag_filename"] = self.log_path + ".db"
        self.rag = RAG(config["rag"])
        # Ablations (single-agentic memory)
        self.memory = config["memory"]
        if (self.memory != "all"):
            if self.memory >= len(self.llms):
                raise ValueError("Memory index should be 'all' or less than the number of agents.")
            print(f"Using {self.llm_names[self.memory]} as the single-agent source of shared memory.")

    def __call__(
        self,
        question: str,
        prompt_zeroshot: str,
        fewshot_template: str,
        **kwargs
    ) -> str:
        # For ablation studies
        if self.memory != "all":
            self.question = question
            self.prompt_zeroshot = prompt_zeroshot
            self.fewshot_template = fewshot_template
        # ------------------
        # Regular operations
        shots = self.rag.retrieve(query=question, top_k=self.rag.top_k) if (self.rag.insert_acc > 0) else []
        # Determine prompt
        if len(shots):
            fewshot_text = "\n\n\n".join(shots).replace("\\", "\\\\")
            try:
                prompt = re.sub(pattern=r"\{fewshot_text\}", repl=fewshot_text, string=fewshot_template)
            except Exception as e:
                error_msg = f"Error ```{e}``` caused by these shots. Logged to jsonl."
                print(error_msg)
                shots.append(error_msg)
                prompt = prompt_zeroshot
        else:
            prompt = prompt_zeroshot
        # Inference
        if self.total_steps < self.warmup_steps:
            arm = self.pull_rr()
        else:
            arm = getattr(self, f"pull_{self.algo_name}")()
        llm = self.llms[arm]
        pred_text, pred_info = llm(
            prompt=prompt,
            max_tokens=self.config["llms"][arm]["max_tokens"],
            temperature=self.config["llms"][arm]["temperature"]
        )
        # Logging
        self.update_log_info(log_data={
            self.llm_names[arm]: 1,
            "num_shots": str(len(shots)),
            "retrieved_shots": shots,
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        return pred_text

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        assert ("self_output" in feedbacks) and ("is_correct" in feedbacks) and ("question" in feedbacks)
        self.update_cur_arm(is_correct=feedbacks["is_correct"])
        question = feedbacks["question"]
        if (self.bench.DATASET_PATH == "hotpot_qa") and (self.bench.DATASET_NAME == "distractor"):
            index = question.index("Question:")
            question = question[index:].strip()
            if self.total_steps <= 1:
                print("Embed question using only the question itself.")
        if self.memory == "all":  # multi-agent memory
            if not feedbacks["is_correct"]:  # only update the memory when the prediction is correct
                return False
            answer = feedbacks["self_output"]
        else:  # single-agent memory (currently copy code from self.__call__)
            if self.total_steps <= 10: # log the first few steps
                print(f"Saving single-agent memory from {self.llm_names[self.memory]}.")
            shots = self.rag.retrieve(query=self.question, top_k=self.rag.top_k) if (self.rag.insert_acc > 0) else []
            if len(shots):
                fewshot_text = "\n\n\n".join(shots).replace("\\", "\\\\")
                try:
                    prompt = re.sub(pattern=r"\{fewshot_text\}", repl=fewshot_text, string=self.fewshot_template)
                except Exception as e:
                    error_msg = f"Error ```{e}``` caused by these shots. Logged to jsonl."
                    print(error_msg)
                    shots.append(error_msg)
                    prompt = self.prompt_zeroshot
            else:
                prompt = self.prompt_zeroshot
            arm = self.memory
            llm = self.llms[arm]
            pred_text, _ = llm(
                prompt=prompt,
                max_tokens=self.config["llms"][arm]["max_tokens"],
                temperature=self.config["llms"][arm]["temperature"]
            )
            # prepare feedbacks["self_output"]
            if isinstance(self.bench, MedicalDiagnosisBench):
                pred_int = self.bench.postprocess_generation(pred_text)
                label_int = int(feedbacks["ground_truth"].split('.')[0])
                if pred_int != label_int:
                    if self.total_steps <= 10:
                        print(f"Single-agent: {self.llm_names[arm]} failed to predict the correct label. Skipping memory update.")
                    return False
                answer = self.bench.get_label_text(pred_int)
            else:
                raise NotImplementedError("Single-agent memory is only implemented for MedicalDiagnosisBench for now.")
        chunk = feedbacks["shot_template"].format(question=question, answer=answer)
        self.rag.insert(key=question, value=chunk)
        return True

    def update_cur_arm(self, is_correct: bool) -> None:
        self.total_steps += 1
        k = self.cur_arm
        if is_correct:
            if (self.method == Method.DTS.value) and (self.S[self.cur_arm] + self.F[self.cur_arm] >= self.C):
                self.S[k] = (self.S[k] + 1) * self.C / (self.C + 1)
                self.F[k] = (self.F[k] + 0) * self.C / (self.C + 1)
                assert abs(self.S[k] + self.F[k] - self.C) < 1
            else:
                self.S[k] += 1
        else:
            if (self.method == Method.DTS.value) and (self.S[self.cur_arm] + self.F[self.cur_arm] >= self.C):
                self.S[k] = (self.S[k] + 0) * self.C / (self.C + 1)
                self.F[k] = (self.F[k] + 1) * self.C / (self.C + 1)
                assert abs(self.S[k] + self.F[k] - self.C) < 1
            else:
                self.F[k] += 1

    def pull_rr(self) -> int:
        self.cur_arm = (self.cur_arm + 1) % self.K
        return self.cur_arm

    def pull_ts(self) -> int:
        # Thompson sampling
        theta = np.random.beta(self.S + 1, self.F + 1)
        self.cur_arm = np.argmax(theta)
        return self.cur_arm

    def pull_dts(self) -> int:
        # The same as Thompson sampling but with a dynamic C (updated in self.update())
        theta = np.random.beta(self.S + 1, self.F + 1)
        self.cur_arm = np.argmax(theta)
        return self.cur_arm

    def get_name(self) -> str:
        llm_names = [llm["model_name"] for llm in self.config["llms"]]
        return "__".join([
            self.config["agent_name"],
            "_".join(llm_names),
            self.config["rag"]["embedding_model"].split('/')[-1],  # remove '/' to avoid incorrect path
            self.config["rag"]["order"],
            str(self.config["rag"]["top_k"]),
            f"memory-{self.config['memory']}",
            f"seed-{self.seed}"
        ])

# Simulation of each method
if __name__ == "__main__":
    import yaml
    from tqdm import tqdm
    from pathlib import Path
    from pprint import pprint
    # Average rewards for each arm (1000 time steps):
    # 0: 0.35 - 0.5
    # 1: 0.40 - 0.54
    # 2: 0.50 - 0.60
    N_ARMS = 3
    TIMESTEPS = 1000
    start_ends = np.array([[0.35, 1.00], [0.60, 0.70], [0.65, 0.66]])
    step_sizes = [(end - start) / TIMESTEPS for start, end in start_ends]
    avg_rewards = {i: [start_ends[i][0] + step_sizes[i] * t for t in range(TIMESTEPS)] for i in range(N_ARMS)}
    
    cfg_path = "configs/agent/multiagent_rag.yml"
    agent_cfg = yaml.safe_load(Path(cfg_path).read_text())
    
    seeds = range(10, 20)
    accs = list()
    for seed in seeds:
        agent_cfg["seed"] = seed
        agent = MultiAgent(agent_cfg)
        
        # Simulation
        n_correct = 0
        for t in tqdm(range(TIMESTEPS)):
            arm = agent()
            is_correct = random.random() < avg_rewards[arm][t]
            feedbacks = {"is_correct": is_correct}
            agent.update(True, **feedbacks)
            agent.log()
            n_correct += is_correct
        acc = n_correct / TIMESTEPS
        accs.append(acc)
        print(f"Accuracy: {acc:.4f}")
    print(f"Average accuracy: {np.mean(accs):.4f}")
