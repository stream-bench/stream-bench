import re
import json
import textwrap
from typing import Any
from .base import Baseline

def extract_retrieve_key(row):
    if 'question' in row and 'knowledge' in row:
        return row['question']
    if 'premise' in row and 'hypothesis' in row:
        return 'Premise: '+row['premise']+'\nHypothesis: '+row['hypothesis']
    elif 'prompt' in row:
        return row['prompt']
           
number_matcher = re.compile(r'Page \[(\d+)((, (\d+))+)?\]')
def parse_page_num(text):
    match = number_matcher.search(text)
    if match:
        page_num = match.group(1)
        if match.group(2):
            page_num = page_num + ',' + match.group(2)
        page_num = [ int(num.strip()) for num in page_num.split(',') if len(num.strip())> 0]
        return page_num
    return []

class ParallelReadAgent(Baseline):
    """
        Generic version of RAG agent for long term memory and recall via embedding model
    """
    GIST_PROMPT = textwrap.dedent("""
    Please shorten the following passage. Just give me a shortened version. DO NOT explain your reason.
    Passage:
    """)
    PARALLEL_LOOKUP = textwrap.dedent("""
    The following text is what you remember from reading an article and a given question related to it.
    You may read 1 to 5 page(s) of the article again to refresh your memory to prepare yourself for the question.
    Please respond with which page(s) you would like to read.
    For example, if you only need to read Page 8, respond with “I want to look up Page [8] to ...”; if you would like to read Page 7 and 12, respond with “I want to look up Page [7, 12] to ...”; 
    if you would like to read Page 2, 3, 7, 15 and 18, respond with “I want to look up Page [2, 3, 7, 15, 18] to ...”.
    DO NOT select more pages if you don’t need to.
    You don’t need to answer the question yet.
    Text:
    {}
    Question:
    {}
    """)
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.config = config
        self.llm_config = config["llm"]
        self.series = self.llm_config["series"]
        self.model_name = self.llm_config["model_name"]
        self.gist2complete = {}

    def __call__(self, prompt: str=None, prompt_zeroshot: str=None, **kwargs) -> str:
        self.reset_log_info()
        if prompt is None and prompt_zeroshot is not None:
            prompt = prompt_zeroshot
        pred_text, pred_info = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        self.update_log_info(log_data={
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        return pred_text

    def update(self, has_feedback:bool, feedback_msg: str, **kwargs) -> bool:
        """
            return true if feedback was memorized
            false if the feedback was discarded either via heuristic reason or llm decision
        """
        if has_feedback:
            prompt = self.GIST_PROMPT + feedback_msg
            res = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )[0]
            self.gist2complete[res] = feedback_msg
            return True
        return False

    def retrieve(self, question):
        if len(self.gist2complete) == 0:
            return []
        page_cache = []
        storage = []
        idx2gist = {}
        for idx, gist in enumerate(self.gist2complete.keys()):
            idx2gist[idx] = gist
            if len(page_cache) >= 5:
                texts = '\n\n'.join([ '<{}> \n{}\n'.format(p[0], p[1]) for p in page_cache ])
                prompt = self.PARALLEL_LOOKUP.format(texts, question)
                res = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )[0]
                storage += parse_page_num(res)
                # parse needed gist id and push into storage
                page_cache = []
            if len(storage) >= 6:
                break
            page_cache.append((idx, gist))
        if len(page_cache) and len(storage) < 6:
            texts = '\n\n'.join([ '<{}> \n{}\n'.format(p[0], p[1]) for p in page_cache ])
            prompt = self.PARALLEL_LOOKUP.format(texts, question)
            res = self.llm(prompt,
                    max_tokens=self.llm_config["max_tokens"],
                    temperature=self.llm_config["temperature"]
                )[0]
            storage += parse_page_num(res)
        results = []
        if len(storage) >= 0:
            for page_num in storage:
                if page_num in idx2gist:
                    results.append(self.gist2complete[idx2gist[page_num]])
        name = self.get_name()
        with open(f'retrieve-anli-{name}.jsonl', 'a') as fout:
            fout.write(json.dumps({'question': question, 'results': results})+'\n')
        return results

    def get_name(self):
        return 'readagent-p-{}-{}'.format(self.series, self.model_name)

    def retrieve_experience(self, row: dict):
        key = extract_retrieve_key(row)
        result = self.retrieve(key)
        if len(result):
            return '\n'.join(result)
        return ''


if __name__ == '__main__':
    texts = ["I want to look up Page [1] to ...",
             "I want to look up Page [1, 2, 13] to ...",
        "I want to look up Page [7] to ..."]
    for text in texts:
        print(parse_page_num(text))