"""
    Implements workflow for webshop interactions
"""
import re
import textwrap
import itertools
from typing import List, Tuple
from .base import Agent
from .utils import text_in_label_set, parse_pred_text
from stream_bench.benchmarks.utils import strip_all_lines
from stream_bench.benchmarks.webshop import (
    format_observation, format_actions, format_available_actions
)

Action = Tuple[str, str] # (action, reason)

def parse_action_with_optional(response: str) -> Tuple[str, str]:
    """
    This should be reformat into a json results
    """
    response = response.replace('**','').replace('##', '')
    # print(response)
    encouraged_result = response.split("Discou", maxsplit=1)[0]
    # encouraged_result = encouraged_result.split(":", maxsplit=1)[1]
    encouraged_result: List[str] = encouraged_result.strip().splitlines()
    encouraged_texts: List[Tuple[str, float, str]] = []
    for rst in encouraged_result:
        if '->' in rst:
            action_text, action_tail = rst.split("->", maxsplit=1)
            action_text = action_text.strip()
            action_tail: List[str] = action_tail.strip().split(maxsplit=1)
            try:
                if ':' in action_tail[0]:
                    score = float(action_tail[0].split(':')[0])
                else:
                    score = float(action_tail[0].strip())
            except ValueError:
                score = 0
                # shitty parser
                if action_tail[0][0] in '0123456789' \
                    and action_tail[0][1] == '.' \
                    and action_tail[0][2] in '0123456789':
                    score = float(action_tail[0][:3])
            element_html: str = action_tail[1].strip() if len(action_tail) > 1 else ""
            encouraged_texts.append((
                action_text.replace('Answer:','').replace('-','').strip(),
                score,
                element_html
            ))
        elif '[' in rst and ']' in rst:
            pattern = r'(search|buy|click)\[(.*?)\]'
            match = re.search(pattern, rst)
            if match:
                action = match.group(1)
                context = match.group(2)
                encouraged_texts.append((f'{action}[{context}]', 0, ''))
    # bad response, we found no good action
    if len(encouraged_texts) == 0:
        # start again
        return ("click[back to search]", 'because previous steps has no good action, try again')
    # tuple of (action, scores: float, reason)
    sorted_texts = sorted(encouraged_texts, key=lambda itm: itm[1], reverse=True)
    first_item_iterator = itertools.islice(sorted_texts, 1)
    highest_result = list(first_item_iterator)[0]
    # action text and reason
    return (highest_result[0], highest_result[2])

def parse_instruct_from_obs(observation):
    return observation.split('Instruction:')[-1].strip().split('\n')[0]

class NoStreamingWebAgent(Agent):
    BASE_PROMPT = textwrap.dedent("""
        I'm visiting a shopping website and need to complete the shopping following an instruction about the desired commodity. On the shopping website, my available actions are:
        
        search[keywords]
        click[element]
        
        Specifically, given an input, I will give some action advices with encouraging or discouraging along with their value estimation, and the reason of this advice if the action is a "click".
        
        Here are several common principles to make a decision:
        
        1. I need to follow the instruction to search and select the most relevant item.
        2. I should only know the properties of the commodity from its description, but not from my imagination.
        3. I may click into a commodity item to check more detailed features.
        4. I can return to the previous page to select a more suitable item if the current commodity cannot satisfy all the requirements.
        5. I will avoid always repeating a wrong action.
        6. I can search only if "search" is listed as an available action. If "search" is not listed as an available action, I need to click "back to search" before conducting a search.
        7. If multiple groups of options are listed in the item page, I should choose an option for all the groups. Then I can click "buy now".
        8. I need to click "buy now" to finish the shopping after all the options are selected.
        9. I should encourage the actions with higher value estimations like 1 and discourage the actions with low value estimations like 0.
        
        Here are some examples:
        
        Example 1:
        Last 5 Actions:
        
        Observation: |
        
        WebShop
        Instruction:
        i would like a 3 ounce bottle of bright citrus deodorant for sensitive skin, and price lower than 40.00 dollars
        [Search]
        Available Actions:
        - search
        
        Output: |
        
        Encouraged:
        search[deodorant sensitive skin] -> 1.0
        search[3 ounce bottle bright citrus deodorant sensitive skin] -> 0.7
        Discouraged:
        click[search] -> 0.0 The search button shouldn't be clicked.
        
        Example 2:
        Last 5 Actions:
        - search[3 ounce bottle bright citrus deodorant sensitive skin]
        Observation: |
        
        Instruction:
        i would like a 3 ounce bottle of bright citrus deodorant for sensitive skin, and price lower than 40.00 dollars
        [Back to Search]
        Page 1 (Total results: 50)
        [Next >]
        [B078GWRC1J]
        Bright Citrus Deodorant by Earth Mama | Natural and Safe for Sensitive Skin, Pregnancy and Breastfeeding, Contains Organic Calendula 3-Ounce
        $10.99
        [B078GTKVXY]
        Ginger Fresh Deodorant by Earth Mama | Natural and Safe for Sensitive Skin, Pregnancy and Breastfeeding, Contains Organic Calendula 3-Ounce
        $10.99
        [B08KBVJ4XN]
        Barrel and Oak - Aluminum-Free Deodorant, Deodorant for Men, Essential Oil-Based Scent, 24-Hour Odor Protection, Cedar & Patchouli Blend, Gentle on Sensitive Skin (Mountain Sage, 2.7 oz, 2-Pack)
        $15.95
        Available Actions:
        - back to search
        - next >
        - b078gwrc1j
        - b078gtkvxy
        - b08kbvj4xn
        
        Output: |
        
        Encouraged:
        click[b078gwrc1j] -> 1.0 b078gwrc1j and b078gtkvxy are bright citrus deodorant less then 50 dollars. I can check b078gwrc1j first.
        Discouraged:
        click[b08kbvj4xn] -> 0.0 b08kbvj4xn is not the desired item.
        
        Now the new input:
        
        {new_input}""")
    INPUT_TEMPLATE = textwrap.dedent("""
        ---
        Last 5 Actions:
        {actions}
        Observation: |
        {observation}
        Available Actions:
        {available_actions}
        
        Output: |
        """)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.max_steps = config['max_steps']

    def _instantiate_input_template(self, observation: str, action_history: List[Action],
                                   available_actions: str
                                ):
        return self.INPUT_TEMPLATE.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
        )

    def step(self, session_id: int,
            observation: str,
            task: str,
            available_actions: List[str],
            action_history: List[Action],
            ):
        # fit all params into a prompt and prompt the llm
        available_actions = "\n".join(available_actions)
        input_str = self._instantiate_input_template(observation,
                                         action_history=action_history,
                                         available_actions=available_actions
                                        )
        prompt = self.BASE_PROMPT.format(new_input=input_str)
        pred_text, pred_info = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        action = parse_action_with_optional(pred_text)
        return action, (prompt, pred_text), pred_info

    def __call__(self, session_id: int,
                observation: str,
                task: str,
                available_actions: List[str],
                time_step:int,
                **kwargs
                ):
        self.reset_log_info()

        env = self.bench.env
        total_reward, reward = 0.0, 0.0
        action_history = []
        succeeds = False
        interactions = []
        
        acc_info_stats = {}
        for step_iter in range(self.max_steps):
            # agent decide what to do
            curr_action, prompt_res_pair, llm_info = self.step(
                            session_id=session_id,
                            task=task,
                            observation=observation,
                            action_history=action_history,
                            available_actions=available_actions,
                            )
            if len(acc_info_stats) == 0:
                acc_info_stats = llm_info
            else:
                for key, value in acc_info_stats.items():
                    if isinstance(value, int):
                        acc_info_stats[key] += value
            interactions.append(prompt_res_pair)
            # action, reason
            action_name = curr_action[0]
            if action_name != None:
                action_history.append(curr_action)
                # sync agent action to environment
                observation, reward, done, _ = env.step(action_name)
                # update environment observation
                total_reward += reward
                available_actions = env.get_available_actions()["clickables"]
                if done:
                    succeeds = reward==1.
                    break

        self.update_log_info(log_data={
            "input_pred": [ pair[0] for pair in interactions],
            "output_pred": [ pair[1] for pair in interactions],
            "logprobs_pred": [],
            "num_inference_call": step_iter+1,
            "num_success_call": step_iter+1,
            "num_input_tokens": acc_info_stats["num_input_tokens"],
            "num_output_tokens": acc_info_stats["num_output_tokens"]
        })

        return {
            'num_steps': len(interactions),
            'success': succeeds,
            'session_id': session_id,
            'total_steps_taken': step_iter+1,
            'total_reward': total_reward
        }

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        return False


class CoTWebAgent(NoStreamingWebAgent):

    def __init__(self, config: dict) -> None:
        super().__init__(config)

    def _instantiate_input_template(self, observation: str, action_history: List[Action],
                                   available_actions: str
                                ):
        question = self.INPUT_TEMPLATE.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
        )
        return self.get_cot_prompt(question)

    def step(self, session_id: int,
            observation: str,
            task: str,
            available_actions: List[str],
            action_history: List[Action],
            ):
        # fit all params into a prompt and prompt the llm
        available_actions = "\n".join(available_actions)
        input_str = self._instantiate_input_template(observation,
                                         action_history=action_history,
                                         available_actions=available_actions
                                        )
        prompt = self.BASE_PROMPT.format(new_input=input_str)
        pred_text, pred_info = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        action = parse_action_with_optional(pred_text)
        return action, (prompt, pred_text), pred_info

    def __call__(self, session_id: int,
                observation: str,
                task: str,
                available_actions: List[str],
                time_step:int,
                **kwargs
                ):
        self.reset_log_info()

        env = self.bench.env
        total_reward, reward = 0.0, 0.0
        action_history = []
        succeeds = False
        interactions = []
        
        acc_info_stats = {}
        for step_iter in range(self.max_steps):
            # agent decide what to do
            curr_action, prompt_res_pair, llm_info = self.step(
                            session_id=session_id,
                            task=task,
                            observation=observation,
                            action_history=action_history,
                            available_actions=available_actions,
                            )
            if len(acc_info_stats) == 0:
                acc_info_stats = llm_info
            else:
                for key, value in acc_info_stats.items():
                    if isinstance(value, int):
                        acc_info_stats[key] += value
            interactions.append(prompt_res_pair)
            # action, reason
            action_name = curr_action[0]
            if action_name != None:
                action_history.append(curr_action)
                # sync agent action to environment
                observation, reward, done, _ = env.step(action_name)
                # update environment observation
                total_reward += reward
                available_actions = env.get_available_actions()["clickables"]
                if done:
                    succeeds = reward==1.
                    break

        self.update_log_info(log_data={
            "input_pred": [ pair[0] for pair in interactions],
            "output_pred": [ pair[1] for pair in interactions],
            "logprobs_pred": [],
            "num_inference_call": step_iter+1,
            "num_success_call": step_iter+1,
            "num_input_tokens": acc_info_stats["num_input_tokens"],
            "num_output_tokens": acc_info_stats["num_output_tokens"]
        })

        return {
            'num_steps': len(interactions),
            'success': succeeds,
            'session_id': session_id,
            'total_steps_taken': step_iter+1,
            'total_reward': total_reward
        }

    @staticmethod
    def get_cot_prompt(question: str) -> str:
        prompt = textwrap.dedent(f"""\
        -- Question: {question}
        
        Now, take a deep breath and work on this problem step-by-step to derive the correct action you should take.
        Provide your output in the following format:
        Rationale: <your_rationale>
        Answer: action_name[value] -> (score)""")
        return strip_all_lines(prompt)


class RAGWebAgent(Agent):

    HIGH_LEVEL_INSTRUCT_PROMPT = textwrap.dedent("""
        I'm visiting a shopping website and need to complete the shopping following an instruction about the desired commodity. On the shopping website, my available actions are:
        
        search[keywords]
        click[element]
        
        Specifically, given an input, I will give some action advices with encouraging or discouraging along with their value estimation, and the reason of this advice if the action is a "click".
        
        Here are several common principles to make a decision:
        
        1. I need to follow the instruction to search and select the most relevant item.
        2. I should only know the properties of the commodity from its description, but not from my imagination.
        3. I may click into a commodity item to check more detailed features.
        4. I can return to the previous page to select a more suitable item if the current commodity cannot satisfy all the requirements.
        5. I will avoid always repeating a wrong action.
        6. I can search only if "search" is listed as an available action. If "search" is not listed as an available action, I need to click "back to search" before conducting a search.
        7. If multiple groups of options are listed in the item page, I should choose an option for all the groups. Then I can click "buy now".
        8. I need to click "buy now" to finish the shopping after all the options are selected.
        9. I should encourage the actions with higher value estimations like 1 and discourage the actions with low value estimations like 0.""")

    CRITIC_ANSWER = "Based on this given question and answer, determine whether the answer is correct or not. State your reasons first and then answer it"
    BASE_PROMPT = textwrap.dedent("""
        ---
        Last 5 Actions:
        {actions}
        Observation: |
        {observation}
        Available Actions:
        {available_actions}

        Output: |
        """)
    FULL_TEMPLATE = textwrap.dedent("""
        {instruction}
        Past experience:
        {history_actions}
        Current website status, look carefully and give your answer:
        {prompt}
        """)

    def __init__(self, config: dict) -> None:
        from transformers import AutoTokenizer, AutoModel
        from localitylens import Pipeline

        super().__init__(config)
        self.max_steps = config['max_steps']
        embedding_name = self.config['rag']['embedding_model']
        self.tokenizer = AutoTokenizer.from_pretrained(embedding_name)
        self.embed_model = AutoModel.from_pretrained(self.config['rag']['embedding_model']).eval()
        dim_size = len(self.encode_data('Test this size'))
        db_name = self.config['rag']['rag_filename']
        if db_name[-3:] != '.db':
            db_name += '.db'
        self.index_feedback = self.config['rag']['index_feedback']
        self.insert_acc = 0
        self.pipeline = Pipeline(db_name, 'action', dim_size)
        self.id2evidence = {}
        self.id2rewards = {}
        self.id_accumulator = 0

    def encode_data(self, sentence):
        import torch
        import numpy as np
        # Tokenize sentences
        encoded_input = self.tokenizer([sentence], padding=True,
                                       truncation=True,
                                       return_tensors='pt'
                                    )
        # for s2p(short query to long passage) retrieval task, add an instruction to query (not add instruction for passages)
        # encoded_input = self.tokenizer([instruction + q for q in queries], padding=True, truncation=True, return_tensors='pt')

        # Compute token embeddings
        with torch.no_grad():
            model_output = self.embed_model(**encoded_input)
            # Perform pooling. In this case, cls pooling.
            sentence_embeddings = model_output[0][:, 0]
        feature = sentence_embeddings.numpy()[0]
        norm = np.linalg.norm(feature)
        return feature / norm


    def retrieve(self, text, top_k=30):
        if self.insert_acc == 0:
            return []
        embedding = self.encode_data(text)
        result = self.pipeline.search(pred_text, embedding, top_k=top_k)
        if len(result):
            result = [self.id2evidence[r['link']] for r in result]
        return result

    def retrieve_experience(self, observation: str, action_history: List[Action], aspect='instruction'):
        if aspect == 'instruction':
            instruct = parse_instruct_from_obs(observation)
        elif aspect == 'historical_action':
            instruct = format_actions(action_history)
        else: # current webpage status
            instruct = observation
        result = self.retrieve(instruct, self.top_k)
        if len(result):
            return '\n--------\n'.join(result)
        return ''

    def _instantiate_input_template(self, observation: str, action_history: List[Action],
                                   available_actions: str
                                ):
        return self.BASE_PROMPT.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
        )
    def step(self, session_id: int,
            observation: str,
            task: str,
            available_actions: List[str],
            action_history: List[Action],
            ):
        # fit all params into a prompt and prompt the llm
        available_actions = "\n".join(available_actions)
        prompt = self._instantiate_input_template(observation=observation,
                                         action_history=action_history,
                                         available_actions=available_actions
                                        )
        experience = self.retrieve_experience(observation, action_history,
                                         aspect=self.index_feedback)
        instruction = self.FULL_TEMPLATE.format(instruction=self.HIGH_LEVEL_INSTRUCT_PROMPT,
                             history_actions=experience,
                             prompt=prompt)
        pred_text, pred_info = self.llm(instruction,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        action = parse_action_with_optional(pred_text)
        return action, (instruction, pred_text), pred_info

    def __call__(self, session_id: int,
                observation: str,
                task: str,
                available_actions: List[str],
                time_step:int,
                **kwargs
                ):
        self.reset_log_info()

        env = self.bench.env
        total_reward, reward = 0.0, 0.0
        action_history = []
        succeeds = False
        interactions = []

        acc_info_stats = {}
        for step_iter in range(self.max_steps):
            # agent decide what to do
            curr_action, prompt_res_pair, llm_info = self.step(
                            session_id=session_id,
                            task=task,
                            observation=observation,
                            action_history=action_history,
                            available_actions=available_actions,
                            )
            if len(acc_info_stats) == 0:
                acc_info_stats = llm_info
            else:
                for key, value in acc_info_stats.items():
                    if isinstance(value, int):
                        acc_info_stats[key] += value
            interactions.append(prompt_res_pair)
            # action, reason
            action_name = curr_action[0]
            if action_name != None:
                past_action_history = action_history
                past_observation = observation
                past_available_actions = available_actions
                # sync agent action to environment
                observation, reward, done, _ = env.step(action_name)
                action_history.append(curr_action)
                # update rag environment
                self.update(True, observation=past_observation,
                            historical_action=past_action_history,
                            reward=reward,
                            available_actions=past_available_actions,
                            feedback_kind=self.index_feedback)
                self.id_acc += 1

                # update environment observation
                total_reward += reward
                available_actions = env.get_available_actions()["clickables"]

                if done:
                    succeeds = reward == 1.
                    break

        self.update_log_info(log_data={
            "input_pred": [ pair[0] for pair in interactions],
            "output_pred": [ pair[1] for pair in interactions],
            "logprobs_pred": [],
            "num_inference_call": step_iter+1,
            "num_success_call": step_iter+1,
            "num_input_tokens": acc_info_stats["num_input_tokens"],
            "num_output_tokens": acc_info_stats["num_output_tokens"]
        })

        return {
            'session_id': session_id,
            'num_steps': len(interactions),
            'success': succeeds,
            'total_steps_taken': step_iter+1,
            'total_reward': total_reward
        }

    def update(self, has_feedback: bool,
               observation: str,
               historical_action: str,
               reward: float,
               available_actions: List[str],
               feedback_kind='observation',
               **kwargs) -> bool:
        if has_feedback:
            if feedback_kind == 'instruction':
                index_text = parse_instruct_from_obs(observation)
            elif feedback_kind == 'historical_action':
                index_text = format_actions(action_history)
            else: # current webpage status
                index_text = observation

            content = self.BASE_PROMPT.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
            )
            executed = 'Encouraged:\n{} -> {:.4f}'.format(action, reward)
            row = {
                'evidence': index_text,
                'link': str(self.id_accumulator)
            }
            embedding = self.encode_data(index_text)
            self.pipeline.insert(row, embedding, 'evidence', 'link')

            self.id2evidence[self.id_accumulator] = content+'\n'+executed
            self.id_accumulator += 1
            return True

        return False

class FewShotAgent(Agent):
    HIGH_LEVEL_INSTRUCT_PROMPT = textwrap.dedent("""\
        I'm visiting a shopping website and need to complete the shopping following an instruction about the desired commodity. On the shopping website, my available actions are:
        
        search[keywords]
        click[element]
        
        Specifically, given an input, I will give some action advices with encouraging or discouraging along with their value estimation, and the reason of this advice if the action is a "click".
        
        Here are several common principles to make a decision:
        
        1. I need to follow the instruction to search and select the most relevant item.
        2. I should only know the properties of the commodity from its description, but not from my imagination.
        3. I may click into a commodity item to check more detailed features.
        4. I can return to the previous page to select a more suitable item if the current commodity cannot satisfy all the requirements.
        5. I will avoid always repeating a wrong action.
        6. I can search only if "search" is listed as an available action. If "search" is not listed as an available action, I need to click "back to search" before conducting a search.
        7. If multiple groups of options are listed in the item page, I should choose an option for all the groups. Then I can click "buy now".
        8. I need to click "buy now" to finish the shopping after all the options are selected.
        9. I should encourage the actions with higher value estimations like 1 and discourage the actions with low value estimations like 0.
        #Response instruction#:
        Reply in Encouraged:
        - <action_name>[<context>] -> <your reward score> reasoning
        Please refer to Examples 1 and 2 for more details
        """)

    CRITIC_ANSWER = "Based on this given question and answer, determine whether the answer is correct or not. State your reasons first and then answer it"
    FEWSHOT = textwrap.dedent("""\
        Examples:
        Example 1:
        Last 5 Actions:
        Observation: |
        WebShop
        Instruction:
        i would like a 3 ounce bottle of bright citrus deodorant for sensitive skin, and price lower than 40.00 dollars
        [Search]
        Available Actions:
        - search
        Output: |
        Encouraged:
        search[deodorant sensitive skin] -> 1.0
        search[3 ounce bottle bright citrus deodorant sensitive skin] -> 0.7
        Discouraged:
        click[search] -> 0.0 The search button shouldn't be clicked.
        Example 2:
        Last 5 Actions:
        - search[3 ounce bottle bright citrus deodorant sensitive skin]
        Observation: |
        Instruction:
        i would like a 3 ounce bottle of bright citrus deodorant for sensitive skin, and price lower than 40.00 dollars
        [Back to Search]
        Page 1 (Total results: 50)
        [Next >]
        [B078GWRC1J]
        Bright Citrus Deodorant by Earth Mama | Natural and Safe for Sensitive Skin, Pregnancy and Breastfeeding, Contains Organic Calendula 3-Ounce
        $10.99
        [B078GTKVXY]
        Ginger Fresh Deodorant by Earth Mama | Natural and Safe for Sensitive Skin, Pregnancy and Breastfeeding, Contains Organic Calendula 3-Ounce
        $10.99
        Available Actions:
        - back to search
        - next >
        - b078gwrc1j
        - b078gtkvxy
        - b08kbvj4xn        
        Output: |
        Encouraged:
        click[b078gwrc1j] -> 1.0 b078gwrc1j are bright citrus deodorant less then 50 dollars. I can check b078gwrc1j first.
        Discouraged:
        click[b078gtkvxy] -> 0.0 b078gtkvxy is not the desired item as its ginger fresh""")
    BASE_PROMPT = textwrap.dedent("""\
        ---
        Last 5 Actions:
        {actions}
        Observation: |
        {observation}
        Available Actions:
        {available_actions}
        
        Output: |
        """)
    FULL_TEMPLATE = textwrap.dedent("""\
        {instruction}
        {fewshot}
        {history_actions}
        Current website status, look carefully and give your answer:
        {prompt}
        """)

    def __init__(self, config: dict) -> None:
        super().__init__(config)


class GrowthWebAgent(FewShotAgent):

    def __init__(self, config: dict) -> None:
        self.series = config["llm"]["series"]
        self.model_name = config["llm"]["model_name"]
        self.top_k = int(config['rag']['top_k'])
        super().__init__(config)
        self.max_steps = config['max_steps']
        self.insert_acc = 0
        self.steps_per_instruct = []
        self.trajectory_accumulation = []
        self.id_accumulator = 0


    def create_template(self, init_observation, action_takens, final_reward):
        instruction = parse_instruct_from_obs(init_observation)
        actions = []
        for idx, (observation, action_pair, reward) in enumerate(action_takens):
            context = observation.split(instruction)[-1]
            action, reason = action_pair
            actions.append('steps {}. observation:\n{}\naction taken {} -> {}'.format(idx+1, context, action, reason))
        trajectory = '\n'.join(actions)
        return "Instruction : {instruction}\nActions taken:\n{trajectory}\nFinal rewards:\n{final_rewards}".format(
            instruction=instruction,
            trajectory=trajectory,
            final_rewards=final_reward
        )

    def retrieve_experience(self):
        result = self.trajectory_accumulation[-self.top_k:]
        if len(result):
            return '\n--------\n'.join([self.create_template(*res) for res in result])
        return ''

    def _instantiate_input_template(self, observation: str, action_history: List[Action],
                                   available_actions: str
                                ):
        return self.BASE_PROMPT.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
        ).strip()

    def step(self, session_id: int,
            observation: str,
            task: str,
            available_actions: List[str],
            action_history: List[Action],
            ):
        # fit all params into a prompt and prompt the llm
        available_actions = "\n".join(available_actions)
        prompt = self._instantiate_input_template(observation=observation,
                                         action_history=action_history,
                                         available_actions=available_actions
                                        )
        experience = self.retrieve_experience()
        instruction = self.FULL_TEMPLATE.format(instruction=self.HIGH_LEVEL_INSTRUCT_PROMPT,
                            history_actions='Previous experiences:\n'+experience,
                            fewshot=self.FEWSHOT,
                            prompt=prompt).strip()
        pred_text, pred_info = self.llm(instruction,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        action = parse_action_with_optional(pred_text)
        return action, (instruction, pred_text), pred_info

    def __call__(self, session_id: int,
                observation: str,
                task: str,
                available_actions: List[str],
                time_step:int,
                **kwargs
                ):
        self.reset_log_info()

        env = self.bench.env
        total_reward, reward = 0.0, 0.0
        action_history = []
        succeeds = False
        interactions = []
        acc_info_stats = {}
        actions_taken = []
        init_observation = observation
        for step_iter in range(self.max_steps):
            # agent decide what to do
            curr_action, prompt_res_pair, llm_info = self.step(
                            session_id=session_id,
                            task=task,
                            observation=observation,
                            action_history=action_history,
                            available_actions=available_actions,
                            )
            if len(acc_info_stats) == 0:
                acc_info_stats = llm_info
            else:
                for key, value in acc_info_stats.items():
                    if isinstance(value, int):
                        acc_info_stats[key] += value
            interactions.append(prompt_res_pair)
            # action, reason
            action_name = curr_action[0]
            if action_name != None:
                past_action_history = action_history
                past_observation = observation
                past_available_actions = available_actions
                # sync agent action to environment
                observation, reward, done, _ = env.step(action_name)
                action_history.append(curr_action)

                # update environment observation
                total_reward += reward
                available_actions = env.get_available_actions()["clickables"]
                actions_taken.append((past_observation, curr_action, reward))
                if done:
                    if reward >= 0.2:
                        self.trajectory_accumulation.append((
                            init_observation,
                            actions_taken,
                            reward
                        ))
                    succeeds = reward == 1.
                    break

        self.update_log_info(log_data={
            "actions": [ act[0][0] for act in actions_taken],
            "logprobs_pred": [],
            "num_inference_call": step_iter+1,
            "num_success_call": step_iter+1,
            "num_input_tokens": acc_info_stats["num_input_tokens"],
            "num_output_tokens": acc_info_stats["num_output_tokens"],
            "input_pred": [ pair[0] for pair in interactions],
            "output_pred": [ pair[1] for pair in interactions],
        })

        return {
            'session_id': session_id,
            'num_steps': len(interactions),
            'success': succeeds,
            'total_steps_taken': step_iter+1,
            'total_reward': total_reward
        }

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        return False

    def get_name(self):
        return 'growprompt-v3-{}-{}-{}'.format(self.series, self.top_k, self.model_name)


class MemPromptAgent(FewShotAgent):

    def __init__(self, config: dict) -> None:
        self.series = config["llm"]["series"]
        self.model_name = config["llm"]["model_name"]
        self.top_k = int(config['rag']['top_k'])
        super().__init__(config)
        self.max_steps = config['max_steps']
        self.insert_acc = 0
        self.steps_per_instruct = []
        self.trajectory_accumulation = []
        self.id_accumulator = 0
        # rag stuff
        embedding_name = self.config['rag']['embedding_model']
        self.tokenizer = AutoTokenizer.from_pretrained(embedding_name)
        self.embed_model = AutoModel.from_pretrained(self.config['rag']['embedding_model']).eval()
        dim_size = len(self.encode_data('Test this size'))
        db_name = self.config['rag']['rag_filename']
        if db_name[-3:] != '.db':
            db_name += '.db'
        self.index_feedback = self.config['rag']['index_feedback']
        self.insert_acc = 0
        self.pipeline = Pipeline(db_name, 'action', dim_size)
        self.id2evidence = {}
        self.id2rewards = {}
        self.id_accumulator = 0

    def encode_data(self, sentence):
        import torch
        import numpy as np
        # Tokenize sentences
        encoded_input = self.tokenizer([sentence], padding=True,
                                       truncation=True,
                                       return_tensors='pt'
                                    )
        # for s2p(short query to long passage) retrieval task, add an instruction to query (not add instruction for passages)
        # encoded_input = self.tokenizer([instruction + q for q in queries], padding=True, truncation=True, return_tensors='pt')

        # Compute token embeddings
        with torch.no_grad():
            model_output = self.embed_model(**encoded_input)
            # Perform pooling. In this case, cls pooling.
            sentence_embeddings = model_output[0][:, 0]
        feature = sentence_embeddings.numpy()[0]
        norm = np.linalg.norm(feature)
        return feature / norm

    def insert_db(self, text, instructions):
        row = {
            'evidence': instructions,
            'link': str(self.id_accumulator)
        }
        embedding = self.encode_data(instructions)
        self.pipeline.insert(row, embedding, 'evidence', 'link')

        self.id2evidence[self.id_accumulator] = text
        self.id_accumulator += 1
        return True

    def retrieve(self, text):
        if self.insert_acc == 0:
            return []
        embedding = self.encode_data(text)
        result = self.pipeline.search(pred_text, embedding, top_k=self.top_k)
        if len(result):
            result = [self.id2evidence[r['link']] for r in result]
        return result

    def create_template(self, init_observation, action_takens, final_reward):
        instruction = parse_instruct_from_obs(init_observation)
        actions = []
        for idx, (observation, action_pair, reward) in enumerate(action_takens):
            context = observation.split(instruction)[-1]
            action, reason = action_pair
            actions.append('steps {}. observation:\n{}\naction taken {} -> {}'.format(idx+1, context, action, reason))
        trajectory = '\n'.join(actions)
        return "Instruction : {instruction}\nActions taken:\n{trajectory}\nFinal rewards:\n{final_rewards}".format(
            instruction=instruction,
            trajectory=trajectory,
            final_rewards=final_reward
        )

    def retrieve_experience(self, instruction):
        result = self.retrieve(instruction)
        if len(result):
            return '\n--------\n'.join([self.create_template(*res) for res in result])
        return ''

    def _instantiate_input_template(self, observation: str, action_history: List[Action],
                                   available_actions: str
                                ):
        return self.BASE_PROMPT.format(
                observation=format_observation(observation),
                actions=format_actions(action_history),
                available_actions=format_available_actions(available_actions)
        ).strip()

    def step(self, session_id: int,
            observation: str,
            task: str,
            available_actions: List[str],
            action_history: List[Action],
            ):
        # fit all params into a prompt and prompt the llm
        available_actions = "\n".join(available_actions)
        prompt = self._instantiate_input_template(observation=observation,
                                         action_history=action_history,
                                         available_actions=available_actions
                                        )
        step_instruction = parse_instruct_from_obs(observation)
        print(step_instruction)
        experience = self.retrieve_experience(step_instruction if len(step_instruction) else observation)
        instruction = self.FULL_TEMPLATE.format(instruction=self.HIGH_LEVEL_INSTRUCT_PROMPT,
                            history_actions='Previous experiences:\n'+experience,
                            fewshot=self.FEWSHOT,
                            prompt=prompt).strip()
        pred_text, pred_info = self.llm(instruction,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        action = parse_action_with_optional(pred_text)
        return action, (instruction, pred_text), pred_info

    def __call__(self, session_id: int,
                observation: str,
                task: str,
                available_actions: List[str],
                time_step:int,
                **kwargs
                ):
        self.reset_log_info()

        env = self.bench.env
        total_reward, reward = 0.0, 0.0
        action_history = []
        succeeds = False
        interactions = []
        acc_info_stats = {}
        actions_taken = []
        init_observation = observation
        for step_iter in range(self.max_steps):
            # agent decide what to do
            curr_action, prompt_res_pair, llm_info = self.step(
                            session_id=session_id,
                            task=task,
                            observation=observation,
                            action_history=action_history,
                            available_actions=available_actions,
                            )
            if len(acc_info_stats) == 0:
                acc_info_stats = llm_info
            else:
                for key, value in acc_info_stats.items():
                    if isinstance(value, int):
                        acc_info_stats[key] += value
            interactions.append(prompt_res_pair)
            # action, reason
            action_name = curr_action[0]
            if action_name != None:
                past_action_history = action_history
                past_observation = observation
                past_available_actions = available_actions
                # sync agent action to environment
                observation, reward, done, _ = env.step(action_name)
                action_history.append(curr_action)

                # update environment observation
                total_reward += reward
                available_actions = env.get_available_actions()["clickables"]
                actions_taken.append((past_observation, curr_action, reward))
                if done:
                    if reward >= 0.5:
                        text = self.create_template(init_observation,
                            actions_taken,
                            reward
                        )
                        instruction = parse_instruct_from_obs(init_observation)
                        self.update(instruction, text)
                    succeeds = reward == 1.
                    break

        self.update_log_info(log_data={
            "actions": [ act[0][0] for act in actions_taken],
            "logprobs_pred": [],
            "num_inference_call": step_iter+1,
            "num_success_call": step_iter+1,
            "num_input_tokens": acc_info_stats["num_input_tokens"],
            "num_output_tokens": acc_info_stats["num_output_tokens"],
            "input_pred": [ pair[0] for pair in interactions],
            "output_pred": [ pair[1] for pair in interactions],
        })

        return {
            'session_id': session_id,
            'num_steps': len(interactions),
            'success': succeeds,
            'total_steps_taken': step_iter+1,
            'total_reward': total_reward
        }

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        return False

    def get_name(self):
        return 'growprompt-v3-{}-{}-{}'.format(self.series, self.top_k, self.model_name)
