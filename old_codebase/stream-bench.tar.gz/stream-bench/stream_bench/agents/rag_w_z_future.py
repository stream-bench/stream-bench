from typing import Any
import torch
import textwrap
import numpy as np
from transformers import AutoTokenizer, AutoModel
from localitylens import Pipeline
from .base import Baseline

def extract_retrieve_key(row):
    if 'question' in row and 'db_id' in row:
        return row['question']
    if 'prompt' in row:
        return row['prompt']
    return ''

class RefinedFeedbackFuture(Baseline):
    """
        Generic version of RAG agent for long term memory and recall via embedding model
    """

    def __init__(self, config: dict) -> None:
        self.config = config
        self.top_k = self.config['rag']['top_k']
        super().__init__(config)
        self.llm_config = config["llm"]
        self.series = self.llm_config["series"]
        self.model_name = self.llm_config["model_name"]
        self.tokenizer = AutoTokenizer.from_pretrained(self.config['rag']['embedding_model'])
        self.embed_model = AutoModel.from_pretrained(self.config['rag']['embedding_model']).eval()
        dim_size = len(self.encode_data('Test this size'))
        db_name = self.config['rag']['rag_filename']
        if db_name[-3:] != '.db':
            db_name += '.db'
        self.db_name = db_name
        self.insert_acc = 0
        self.pipeline = Pipeline(db_name, 'evidence', dim_size)
        self.id2evidence = {}

    def encode_data(self, sentence):
        # Tokenize sentences
        encoded_input = self.tokenizer([sentence], padding=True, 
                                       truncation=True, 
                                       return_tensors='pt')
        # for s2p(short query to long passage) retrieval task, add an instruction to query (not add instruction for passages)
        # encoded_input = self.tokenizer([instruction + q for q in queries], padding=True, truncation=True, return_tensors='pt')

        # Compute token embeddings
        with torch.no_grad():
            model_output = self.embed_model(**encoded_input)
            # Perform pooling. In this case, cls pooling.
            sentence_embeddings = model_output[0][:, 0]
        feature = sentence_embeddings.numpy()[0]
        norm = np.linalg.norm(feature)
        return feature / norm


    def __call__(self, prompt: None, **kwargs) -> str:
        self.reset_log_info()
        pred_text, pred_info = self.llm(prompt,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        self.update_log_info(log_data={
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        return pred_text

    def rewrite_feedback(self, feedback_msg: str):
        prompt = textwrap.dedent("""
        Please generate the step by step reasoning steps based on the given context to reach final answers.
        The reasoning text must be short and concise and must not be too long. Max character 256.
        Do not copy and paste context.
        This reasoning should include the initial questions, your reasoning and final answers.
        In the future you will be given this feedback when you encounter similar question! So write your reasoning with this in mind.
        # CONTEXT
        """).strip()

        res = self.llm(prompt+'\n\n```\n'+feedback_msg+'\n````\n# REASONING:',
                    max_tokens=512,
                    temperature=0.7
                    )
        return res[0]


    def update(self, has_feedback:bool, feedback_msg: str, **kwargs) -> bool:
        """
            return true if feedback was memorized
            false if the feedback was discarded either via heuristic reason or llm decision
        """
        time_step = kwargs['time_step']
        if has_feedback:
            for _ in range(10):
                refined_knowledge = self.rewrite_feedback(feedback_msg)
                x = self.bench.get_input(kwargs, feedback=refined_knowledge)
                model_output = self(**x)
                prediction = self.bench.postprocess_generation(model_output, time_step)
                label = self.bench.get_output(kwargs)
                res = self.bench.process_results(
                                        prediction,
                                        label,
                                        return_details=True,
                                        simulate_env=True,
                                        time_step=time_step
                                    )
                if res['correct']:
                    break

            row = {
                'evidence': refined_knowledge,
                'link': str(self.insert_acc)
            }
            embedding = self.encode_data(refined_knowledge)
            self.pipeline.insert(row, embedding, 'evidence', 'link')
            self.id2evidence[str(self.insert_acc)] = refined_knowledge
            self.insert_acc += 1
            return True
        return False

    def retrieve(self, text, top_k=30):
        if self.insert_acc == 0:
            return []

        embedding = self.encode_data(text)
        result = self.pipeline.search(text, embedding, top_k=top_k)
        if len(result):
            result = [self.id2evidence[r['link']] for r in result]
        return result

    def get_name(self):
        return 'ragz-future-{}-{}-{}'.format(self.series, self.top_k, self.model_name)

    def retrieve_experience(self, row):        
        key = extract_retrieve_key(row)
        result = self.retrieve(key, self.top_k)
        if len(result):
            return '\n--------\n'.join(result)
        return ''
