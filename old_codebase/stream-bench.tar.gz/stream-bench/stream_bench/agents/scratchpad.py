import re
import textwrap
from enum import Enum
from collections import deque
from typing import Any
from stream_bench.agents.base import Agent, Baseline

class Method(Enum):
    GROW_PROMPT = "grow_prompt"

class ScratchPadAgent(Agent):
    METHODS = {member.value for member in Method}
    CHUNK_DELIMITER = "\n\n\n"

    def __init__(self, config: dict) -> None:
        assert config["agent_name"] in self.METHODS
        assert config["mode"] in {"only_correct", "only_incorrect", "normal"}
        self.mode = config["mode"]
        super().__init__(config)
        self.method = config["agent_name"]
        self.top_k = config["top_k"]  # Preserve information about the most recent k instances on the scratchpad (suitable for GrowPrompt, ...)
        self.dq = deque()  # Deque for implementing sliding window (constant time operations)

    def __call__(
        self,
        question: str,
        prompt_zeroshot: str,
        fewshot_template: str,
        **kwargs
    ):
        error_msg = ""
        # Determine the contents
        chunks = list()
        y_chunks = list()
        n_chunks = list()
        not_corr_verb = "not correct"
        
        for chunk in self.dq:
            if chunk.strip().endswith(not_corr_verb):
                n_chunks.append(chunk)
            else:
                y_chunks.append(chunk)
        
        if self.mode == "normal":
            chunks = self.dq
        elif self.mode == "only_correct":
            chunks = y_chunks
        elif self.mode == "only_incorrect":
            chunks = n_chunks
        
        contents = ""
        if len(chunks) > 0:
            contents = self.CHUNK_DELIMITER.join(chunks).replace("\\", "\\\\")  # make it a raw string
            try:
                prompt = re.sub(pattern=r"\{fewshot_text\}", repl=contents, string=fewshot_template)
            except Exception as e:
                error_msg = f"Error ```{e}``` caused by these shots. Logged to jsonl."
                print(error_msg)
                prompt = prompt_zeroshot                
        else:
            prompt = prompt_zeroshot
        # Inference
        pred_text, pred_info = self.llm(prompt=prompt, max_tokens=self.llm_config["max_tokens"], temperature=self.llm_config["temperature"])
        # logging
        self.update_log_info(log_data={
            "num_chunks": str(len(chunks)),
            "num_correct_chunks": str(len(y_chunks)),
            "num_incorrect_chunks": str(len(n_chunks)),
            "chunks": contents,
            "input_pred": prompt,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"],
            "error_msg": error_msg
        })
        return pred_text

    def update(self, has_feedback: bool, **feedbacks) -> bool:
        question = feedbacks["question"]
        if self.method == Method.GROW_PROMPT.value:
            assert ("self_output" in feedbacks) and ("is_correct" in feedbacks)
            answer = feedbacks["self_output"]
            if feedbacks["is_correct"]:
                corr_verb = "correct"
            else:
                corr_verb = "not correct"
            correctness_text = f"Your answer is {corr_verb}"
        else:
            raise NotImplementedError

        if self.method == Method.GROW_PROMPT.value:
            chunk = feedbacks["memprompt_template"].format(question=question, answer=answer, correctness=correctness_text)
            self.dq.append(chunk)
            if len(self.dq) > self.top_k:
                self.dq.popleft()
        else:
            raise NotImplementedError
        return True

    def get_name(self) -> str:
        return "__".join([
            f'{self.config["agent_name"]}-{self.config["mode"]}',
            self.llm_config["series"],
            self.llm_config["model_name"],
            str(self.config["top_k"]) + "-chunks",
            f"seed-{self.config['seed']}"
        ])

class MemoryScrubber(Baseline):
    """
        Formally known as scratchpad ( note there's no agent behind )
        Generic version of RAG agent for long term memory and recall via embedding model
    """
    REASONING = textwrap.dedent("""
    Do not answer this question yet, finish the following instruction first
    ## INSTRUCTION : Based on the scratchpad and current questions, give me step by step reasoning regarding of our current questions to reach the final solution.
    ## Step-by-Step Reasoning:
    """)

    def __init__(self, config: dict) -> None:
        self.config = config
        self.top_k = self.config['rag']['top_k']
        super().__init__(config)
        self.llm_config = config["llm"]
        self.series = self.llm_config["series"]
        self.model_name = self.llm_config["model_name"]
        self.insert_acc = 0
        self.scratch_pad = ''

    def __call__(self, prompt: str=None, prompt_zeroshot: str=None, **kwargs) -> str:
        self.reset_log_info()
        if prompt is None and prompt_zeroshot is not None:
            prompt = prompt_zeroshot

        reasoning, _ = self.llm(prompt+'\n\n'+self.REASONING,
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )

        pred_text, pred_info = self.llm(prompt +'Reasoning:\n'+reasoning+'\nDirect Answer:',
                       max_tokens=self.llm_config["max_tokens"],
                       temperature=self.llm_config["temperature"]
                    )
        self.update_log_info(log_data={
            "input_pred": prompt,
            "reasoning": reasoning,
            "output_pred": pred_text,
            "logprobs_pred": pred_info["logprobs"],
            "num_inference_call": 1,
            "num_success_call": 1 if (pred_text[:5] != "error") else 0,
            "num_input_tokens": pred_info["num_input_tokens"],
            "num_output_tokens": pred_info["num_output_tokens"]
        })
        return pred_text

    def rewrite_feedback(self, feedback_msg: str):
        prompt = textwrap.dedent("""
        Based on the following context you can freely modify the scratchpad text.
        The purpose of scratchpad is to provide a side note when you are answering future questions.
        Rules of using scratchpad:
        1. Only writes things about the on going tasks
        2. Do not write anything which is limited to this questions
        3. anything written on it must be useful for future questions.
        4. scratch pad text size is limited to 1024 tokens roughly 2048 words. Use it wisely
        5. The next question may or may not be the same context as this question but the task is the same.
        # CONTEXT
        %s
        # END OF CONTEXT
        # START OF SCRATCHPAD
        %s
        # END OF SCRATCHPAD
        Now give me the new updated the scratch pad as you see fit
        # UPDATED SCRATCHPAD
        """).strip()

        res = self.llm(prompt % (feedback_msg, self.scratch_pad),
                    max_tokens=1024,
                    temperature=0.7
                    )
        return res[0]

    def update(self, has_feedback:bool, feedback_msg: str, **kwargs) -> bool:
        """
            return true if feedback was memorized
            false if the feedback was discarded either via heuristic reason or llm decision
        """
        if has_feedback:
            new_scratch_pad = self.rewrite_feedback(feedback_msg)
            self.scratch_pad = new_scratch_pad
            return True
        return False

    def get_name(self):
        return 'scratchpad-{}-{}'.format(self.series, self.model_name)

    def retrieve_experience(self, row):
        return self.scratch_pad