import random
import textwrap
import evaluate
from typing import Any
from datasets import Dataset

from stream_bench.benchmarks.base import Bench

class ANLIBench(Bench):
    DATASET_PATH = "facebook/anli"
    DATASET_NAME = ""

    LABEL2TEXT = {
        0: "entailment",
        1: "neutral",
        2: "contradiction"
    }
    NOTINLABEL = len(LABEL2TEXT)
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}
    LABEL_SET = {v.lower() for v in LABEL2TEXT.values()}

    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    INSTRUCTION = "Based on the premise and hypothesis provided, determine the relationship between them. Choose the appropriate answer from the following options (one option per line):"
    OPTIONS = "\n    ".join(LABEL2TEXT.values())  # NOTE: the four spaces are necessary for textwrap.dedent() formatting
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Premise: {{premise}}
    Hypothesis: {{hypothesis}}
    Answer (please only answer with a single word):""")
    # Zero-shot chain of thought
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Premise: {{premise}}
    Hypothesis: {{hypothesis}}
    Answer (generate the rationale before providing the final answer):""")
    # Few-shot
    PROMPT_FEWSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Here are some example cases.

    {{{{fewshot_text}}}}

    Now answer the following case.

    {{question}}
    Answer:""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{model_output}}
    
    Convert the model output into one of the following options (one option per line):
    {OPTIONS}
    
    Answer (please only answer with a single word):""")
    # Few-shot template
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Here are some example cases.

    {{{{fewshot_text}}}}

    Now answer the following case.

    {{question}}
    Answer:""")
    # Question template
    QUESTION_TEMPLATE = textwrap.dedent(f"""\
    Premise: {{premise}}
    Hypothesis: {{hypothesis}}""")
    # Shot template
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    Answer: {{answer}}""")

    def __init__(
        self,
        split: str = "dev_r3",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        agent=None,
        **kwargs
    ) -> None:
        super().__init__({})
        print("Finish loading ANLI dataset.")
        self.split = split
        self.seed = int(seed)
        self.feedback = feedback
        self.agent_callback = None
        if hasattr(agent, 'retrieve_experience'):
            self.agent_callback = agent.retrieve_experience

    def get_dataset(self) -> Dataset:
        return self.dataset[self.split].shuffle(seed=self.seed)

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        question = self.QUESTION_TEMPLATE.format(premise=row["premise"], hypothesis=row["hypothesis"])
        prediction = self.postprocess_generation(res=model_output, idx=-1)
        if prediction in self.LABEL2TEXT:
            self_output = self.LABEL2TEXT[prediction]
        else:
            print(f"Prediction not in the label set. Randomly sample a label as self output...")
            self_output = random.sample(list(self.LABEL_SET), k=1)[0]
        ground_truth = self.LABEL2TEXT[row["label"]]
        if self.feedback == "no_user_feedback":
            return False, {"question": question, "self_output": self_output, "shot_template": self.SHOT_TEMPLATE}
        elif self.feedback == "ground_truth":
            feedback_msg = '{}\n{}\n{}\nAnswer:\n{}'.format(self.INSTRUCTION, self.OPTIONS, question, ground_truth)
            return True, {
                            "question": question, 
                            "self_output": self_output,
                            "ground_truth": ground_truth,
                            "shot_template": self.SHOT_TEMPLATE,
                            "feedback_msg": feedback_msg
                        }
        raise NotImplementedError

    def get_input(self, row: dict, feedback: str=None) -> dict:
        """Return the baseline prompt and input fields for serving as the agent's input."""
        row_input = {key: row[key] for key in ["uid", "premise", "hypothesis"]}
        row_input["question"] = self.QUESTION_TEMPLATE.format(premise=row["premise"], hypothesis=row["hypothesis"])
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(premise=row["premise"], hypothesis=row["hypothesis"])
        row_input["prompt_cot"] = self.PROMPT_COT.format(premise=row["premise"], hypothesis=row["hypothesis"])
        row_input["prompt_fewshot"] = self.FEWSHOT_TEMPLATE.format(question=row_input["question"]).format(fewshot_text=self.get_fewshot_text())
        row_input["parse_template"] = self.PROMPT_PARSE
        row_input["label_set"] = self.LABEL_SET
        row_input["fewshot_template"] = self.FEWSHOT_TEMPLATE.format(question=row_input["question"])
        reference_prefix = None
        if self.agent_callback is not None:
            feedback = self.agent_callback(row)
            reference_prefix = "## reference materials:\n"+ feedback + "\n## End of reference material\n"
        elif feedback is not None:
            reference_prefix = "## reference materials:\n"+ feedback + "\n## End of reference material\n"
        if reference_prefix is not None:
            row_input["prompt_zeroshot"] = reference_prefix + row_input["prompt_zeroshot"]
            row_input["prompt_cot"] = reference_prefix + row_input["prompt_cot"]

        return row_input

    def get_output(self, row: dict) -> int:
        return row["label"]

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = res.lower().strip()
        if res not in self.LABEL_SET:
            prediction = None
            for text in self.LABEL2TEXT.values():
                if text in res.lower():
                    prediction = self.TEXT2LABEL[text]
                    break
            if prediction is None:
                prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def process_results(self, prediction: Any, label: Any, return_details: bool = False, **kwargs) -> bool | dict:
        """Takes the list of LM generations and evaluates them against ground truth references,
        returning the metric for the generations.
        :param generations: list(list(str))
            list of lists containing generations
        :param labels: original labels
            list of str containing refrences
        """
        accuracy = evaluate.load("accuracy")
        correct = prediction == label
        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions,
                                       references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_fewshot_text(self, train_split: str = "train_r1", k: int = 16) -> str:
        """Generate the few-shot exmaples.

        Few-shot text is in the following format:
        Premise: <premise>
        Hypothesis: <hypothesis>
        Answer: <answer>
        """
        n = len(self.dataset[train_split])
        random.seed(self.seed)  # NOTE: the current implementation is static few-shot
        indices = random.sample(range(n), k)
        shots = list()
        for index in indices:
            instance = self.dataset[train_split][index]
            question = self.get_question_text(instance)
            answer = self.get_answer_text(instance)
            shot = self.SHOT_TEMPLATE.format(
                question=question,
                answer=answer
            )
            shots.append(shot)
        return "\n\n\n".join(shots)

    def get_question_text(self, row):
        return self.QUESTION_TEMPLATE.format(
                premise=row["premise"],
                hypothesis=row["hypothesis"]
            )
    def get_choices_text(self, row):
        return ''

    def get_answer_text(self, row):
        return self.LABEL2TEXT[row["label"]]

if __name__ == "__main__":
    bench = ANLIBench()
    for time_step, row in enumerate(bench.get_dataset()):
        x = bench.get_input(row)
        print(x["prompt_zeroshot"], end="\n\n\n==========\n")
        print(x["prompt_cot"], end="\n\n\n==========\n")
        print(x["prompt_fewshot"], end="\n\n\n==========\n")
        if time_step == 0:
            break
