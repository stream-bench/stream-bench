import random
import evaluate
import textwrap
from abc import ABC, abstractmethod
from typing import Any
from datasets import load_dataset, Dataset

class Bench(ABC):
    """Associated with corresponding Dataset, Feedback, and Metrics"""
    DATASET_PATH: str = None
    DATASET_NAME: str = None

    def __init__(self, config: dict):
        self.config = config
        self.dataset = load_dataset(self.DATASET_PATH, self.DATASET_NAME)
        self.use_wandb = False
        self.n_correct = 0
        self.references = []
        self.predictions = []

    @abstractmethod
    def get_dataset(self) -> Dataset:
        raise NotImplementedError

    @abstractmethod
    def give_feedback(self, model_output: str, row: dict, res: dict) -> tuple[bool, dict]:
        """Give feedback according to benchmark configurations.

        1. No feedback
        2. Weak feedback (True: correct, False: incorrect)
        3. Strong feedback (Ground truth string)
        """
        raise NotImplementedError

    @abstractmethod
    def get_input(self, row: dict) -> dict:
        """
        return must include prompt field of string value
        """
        raise NotImplementedError

    @abstractmethod
    def get_output(self, row: dict) -> dict:
        """Extract the label of the row (instance)."""
        raise NotImplementedError

    @abstractmethod
    def get_metrics(self) -> dict:
        """Calculate and return the metrics for this benchmark."""
        raise NotImplementedError

    @abstractmethod
    def postprocess_generation(self, res: Any, idx: int) -> Any:
        """Postprocess the agent's response and map it to the label space.

        Args:
            res (Any): the agent's response
            idx (int): the instance's index in the dataset

        Returns:
            Any: the predicted label
        """
        raise NotImplementedError

    @abstractmethod
    def process_results(self, prediction: Any, label: Any, return_details: bool = False) -> bool | dict:
        """Compare the prediction with the label and calculate streaming metrics at the current time point.

        Args:
            prediction (Any): the agent's prediction
            label (Any): the ground truth label
            return_details (bool, optional): Return correctness of prediction (bool) or detailed metrics (dict). Defaults to False

        Returns:
            bool | dict:  Return correctness of prediction (bool) or detailed metrics (dict)
        """
        raise NotImplementedError

class MCQBench(Bench):
    """A base benchmark class for multiple-choice questions (MCQS)"""
    INPUT_FIELDS = []  # NOTE: remember to specify input fields in the subclass

    LABEL2TEXT = {0: 'A', 1: 'B', 2: 'C', 3: 'D'}
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}
    NOTINLABEL = len(LABEL2TEXT)
    LABEL_SET = {'A', 'B', 'C', 'D'}
    LABEL_SEQ = ['A', 'B', 'C', 'D']
    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    INSTRUCTION = "Answer the following Multiple-Choice Question."
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    Answer (please only answer with a single letter):""")
    # Zero-shot chain of thought
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    Answer (generate the rationale before providing the final answer):""")
    # Few-shot
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}

    Here are some example cases.
    
    {{{{fewshot_text}}}}
    
    Now answer the following case.
    
    {{question}}
    Answer:""")
    # Shot template
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    Answer: {{answer}}""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{{{model_output}}}}
    
    Convert the model output into one of the following options (one option per line):
    {{choices}}
    
    Answer (please only answer with a single letter):""")

    def __init__(
        self,
        split: str = "validation",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        num_shots: int = 16,
        **kwargs
    ) -> None:
        super().__init__({})
        self.split = split
        self.seed = seed
        self.feedback = feedback
        self.num_shots = num_shots

    def get_dataset(self) -> Dataset:
        raise NotImplementedError

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        question = self.get_question_text(row)
        prediction = self.postprocess_generation(res=model_output, idx=-1)
        if prediction in self.LABEL2TEXT:
            self_output = self.get_answer_text(row, prediction)
        else:
            print(f"Prediction not in the label set. Randomly sample a label as self output...")
            random_idx = random.sample(range(len(self.LABEL_SET)), k=1)[0]
            self_output = self.get_answer_text(row, random_idx)
        ground_truth = self.get_answer_text(row, self.get_answer_index(row))
        if self.feedback == "no_user_feedback":
            return False, {"question": question, "self_output": self_output, "shot_template": self.SHOT_TEMPLATE}
        elif self.feedback == "ground_truth":
            return True, {"question": question, "self_output": self_output, "ground_truth": ground_truth, "shot_template": self.SHOT_TEMPLATE}
        raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        """Return the baseline prompt and input fields for serving as the agent's input."""
        row_input = {key: row[key] for key in self.INPUT_FIELDS}
        question, fewshot_text = self.get_question_text(row), self.get_fewshot_text(row)
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(question=question)
        row_input["prompt_cot"] = self.PROMPT_COT.format(question=question)
        # row_input["prompt_fewshot"] = self.FEWSHOT_TEMPLATE.format(question=question).format(fewshot_text=fewshot_text)
        row_input["parse_template"] = self.PROMPT_PARSE.format(choices=self.get_choices_text(row))
        row_input["label_set"] = self.LABEL_SET
        row_input["question"] = question
        # row_input["fewshot_template"] = self.FEWSHOT_TEMPLATE.format(question=question)
        return row_input

    def get_output(self, row: dict) -> int:
        raise NotImplementedError

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = res.upper().strip()
        if res not in self.LABEL_SET:
            prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def process_results(self, prediction: int, label: int, return_details: bool = False) -> bool | dict:
        accuracy = evaluate.load("accuracy")
        correct = prediction == label

        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions, references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_question_text(self, row: dict) -> str:
        raise NotImplementedError

    def get_choices_text(self, row: dict) -> str:
        raise NotImplementedError

    def get_answer_text(self, row: dict, label: int) -> str:
        raise NotImplementedError

    def get_answer_index(self, row: dict) -> int:
        raise NotImplementedError

    def get_fewshot_text(self, row: dict) -> str:
        raise NotImplementedError

    def extract_fewshot_examples(self):
        raise NotImplementedError
