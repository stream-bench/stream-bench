import re
import random
import textwrap
import evaluate
from datasets import Dataset

from stream_bench.benchmarks.base import Bench

class ArcBench(Bench):
    DATASET_PATH = "allenai/ai2_arc"
    DATASET_NAME = "ARC-Challenge"

    LABEL2TEXT = {0: 'A', 1: 'B', 2: 'C', 3: 'D'}
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}
    NOTINLABEL = len(LABEL2TEXT)
    LABEL_SET = {'A', 'B', 'C', 'D'}
    NUM_LABEL_SET = {'1', '2', '3', '4'}
    NUM_LABEL2SET = {0: '1', 1: '2', 2: '3', 3: '4'}
    LABEL_SEQ = ['A', 'B', 'C', 'D']

    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    # NOTE: Currently the prompt templates are 100% the same  as the ones in mmlu.py (Prompt formats adapted from https://github.com/openai/evals/blob/main/examples/mmlu.ipynb)
    INSTRUCTION = "Answer the following Multiple-Choice Question."
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    {{choices}}
    Answer (please only answer with a single letter):""")
    # Zero-shot chain of thought
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    Answer (generate the rationale before providing the final answer):""")
    # Few-shot
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}
    Answer options are A, B, C, D
    
    Here are some example cases.
    
    {{{{fewshot_text}}}}
    Now answer the following case.
    
    {{question}}
    {{choices}}
    Answer (please only answer with a single letter):""")
    # Shot template
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    {{choices}}
    Answer: {{answer}}""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{{{model_output}}}}

    Convert the model output into one of the following options (one option per line):
    {{choices}}

    Answer (please only answer with a single letter):""")

    def __init__(
        self,
        split: str = "validation",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        num_shots: int = 16,
        **kwargs
    ) -> None:
        super().__init__({})
        self.split = split
        self.seed = int(seed)
        self.feedback = feedback
        self.num_shots = num_shots
        self.fewshot_examples = self.extract_fewshot_examples()

    def get_dataset(self) -> Dataset:
        return self.dataset[self.split].shuffle(seed=self.seed)

    def parse_answer(self, text):
        matches = [
            r'ANSWER IS \*\*([A-D]|[0-4])',
            r'ANSWER IS\*\*([A-D]|[0-4])',
            r'answer is\*\*([A-D]|[0-4])',
            r'answer is ([A-D]|[0-4])',
            r'## ANSWER: \n\n\*\*([A-D]|[0-4])',
            r'## ANSWER: ([A-D]|[0-4])',
            r'Answer: ([A-D]|[0-4])',
            r'nswer is \*\*([A-D]|[0-4])\*\*.'
            r'## ([A-D]|[0-4]).',
            r'## ([A-D]|[0-4])',
            r'([A-D]|[0-4]).',
        ]
        for match_re in matches:
            if re.findall(match_re, text):
                return re.findall(match_re, text)[0]
        return text

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        question = self.get_question_text(row)
        prediction = self.postprocess_generation(res=model_output, idx=-1)
        if prediction in self.LABEL2TEXT:
            self_output = self.get_answer_text(row, prediction)
        else:
            print(model_output)
            print(prediction, self.LABEL2TEXT, row['choices'])
            print(f"Prediction not in the label set. Randomly sample a label as self output...")
            random_idx = random.sample(range(len(self.LABEL_SET)), k=1)[0]
            self_output = self.get_answer_text(row, random_idx)
        ground_truth = self.get_answer_text(row, self.TEXT2LABEL[row["answerKey"]])
        if self.feedback == "no_user_feedback":
            return False, {"question": question, "self_output": self_output, "shot_template": self.SHOT_TEMPLATE}
        elif self.feedback == "ground_truth":
            return True, {"question": question, "self_output": self_output, "ground_truth": ground_truth, "shot_template": self.SHOT_TEMPLATE}
        raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        """Return the baseline prompt and input fields for serving as the agent's input."""
        row_input = {key: row[key] for key in ["question", "choices"]}
        question, fewshot_text = self.get_question_text(row), self.get_fewshot_text()
        choices = self.get_choices_text(row)
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(question=question, choices=choices)
        row_input["prompt_cot"] = self.PROMPT_COT.format(question=question)
        row_input["prompt_fewshot"] = self.FEWSHOT_TEMPLATE.format(question=question, choices=choices).format(fewshot_text=fewshot_text)
        row_input["parse_template"] = self.PROMPT_PARSE.format(choices=self.get_choices_text(row))
        row_input["label_set"] = self.LABEL_SET
        row_input["question"] = question
        row_input["fewshot_template"] = self.FEWSHOT_TEMPLATE.format(question=question, choices=choices)
        return row_input

    def get_output(self, row: dict) -> int:
        # assert row["answerKey"] in self.LABEL_SET
        text2label = { label: idx for idx, label in  enumerate(row['choices']['label']) }

        return text2label[row["answerKey"]]

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = self.parse_answer(res.upper().strip())
        if res in self.NUM_LABEL_SET:
            prediction = self.NUM_LABEL2SET[res]
        elif res not in self.LABEL_SET:
            prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def process_results(self, prediction: int, label: int, return_details: bool = False, **kwargs) -> bool | dict:
        accuracy = evaluate.load("accuracy")
        correct = prediction == label

        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions, references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_question_text(self, row: dict) -> str:
        return row["question"].strip()

    def get_choices_text(self, row: dict) -> str:
        choices = row["choices"]
        # assert len(self.LABEL_SEQ) == len(choices["label"])
        lines = list()
        for i in range(len(self.LABEL_SEQ)):
            key = choices["label"][i]
            value = choices["text"][i]
            line = f"{key}. {value}"
            lines.append(line)
        return '\n'.join(lines).strip('" \n').strip()

    def get_answer_text(self, row: dict, predict: dict=None) -> str:
        text2label = { label: idx for idx, label in  enumerate(row['choices']['label']) }
        if predict is None:
            label = text2label[row["answerKey"]]
        else:
            if isinstance(predict, int):
                label = predict
            else:
                label = text2label[predict]

        choice = row["choices"]
        key = choice["label"][label]
        value = choice["text"][label]

        return f"{key}. {value}".strip('" \n').strip()

    def get_fewshot_text(self) -> str:
        rows = self.fewshot_examples
        shots = list()
        for row in rows:
            question = self.get_question_text(row)
            answer = self.get_answer_text(row)
            choices = self.get_choices_text(row)
            shot = self.SHOT_TEMPLATE.format(question=question, choices=choices, answer=answer)
            shots.append(shot)
        return "\n\n\n".join(shots).strip('" \n').strip()

    def extract_fewshot_examples(self) -> list[dict[str, str]]:
        """Extract few-shot examples from the training sets of MedQA."""
        fewshot_pool = self.dataset["train"].shuffle(seed=self.seed)
        fewshot_examples = list()
        for i in range(self.num_shots):
            row = fewshot_pool[i]
            fewshot_examples.append(row)
        return fewshot_examples



if __name__ == "__main__":
    # def print_prompts(bench: Bench) -> None:
    #     row = bench.get_dataset()[0]
    #     x = bench.get_input(row)
    #     print(x["prompt_zeroshot"], end="\n\n\n==========\n")
    #     print(x["prompt_cot"], end="\n\n\n==========\n")
    #     print(x["prompt_fewshot"], end="\n\n\n==========\n")
    #     print(x["parse_template"], end="\n\n\n==========\n")

    usmle = ArcBench()
    # print_prompts(usmle)
    for row in usmle.get_dataset():
        print(row['choices']['label'])