import textwrap
from datasets import Dataset

from stream_bench.benchmarks.base import MCQBench

class CMMLUBench(MCQBench):
    DATASET_PATH = "appier-ai-research/cmmlu_all"
    DATASET_NAME = ""
    INPUT_FIELDS = ["subject", "Question", 'A', 'B', 'C', 'D']
    MAX_NUM_SHOTS = 5

    INSTRUCTION = "回答以下单选题。"
    # 标准零样本
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    回答（请仅以单个字母回答）：""")
    # 零样本思维链
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    回答（在提供最终答案前生成理由）：""")
    # 少样本
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}

    以下是一些示例案例。
    
    {{{{fewshot_text}}}}
    
    现在回答以下案例。
    
    {{question}}
    回答：""")
    # 样本模板
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    回答：{{answer}}""")
    # 解析输出以映射到标签空间的提示
    PROMPT_PARSE = textwrap.dedent(f"""\
    模型输出：{{{{model_output}}}}
    
    将模型输出转换为以下选项之一（每行一个选项）：
    {{choices}}
    
    回答（请仅以单个字母回答）：""")

    def __init__(
        self,
        split: str = "test",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        num_shots: int = 5,
        **kwargs
    ) -> None:
        assert num_shots <= self.MAX_NUM_SHOTS
        super().__init__({})
        self.split = split
        self.seed = seed
        self.feedback = feedback
        self.num_shots = num_shots
        self.fewshot_examples = self.extract_fewshot_examples()

    def get_dataset(self) -> Dataset:
        return self.dataset[self.split].shuffle(seed=self.seed)

    def get_output(self, row: dict) -> int:
        return self.TEXT2LABEL[row["Answer"]]

    def get_question_text(self, row: dict) -> str:
        text = row["Question"].strip() + '\n' + self.get_choices_text(row)
        return text.strip()

    def get_choices_text(self, row: dict) -> str:
        lines = list()
        for letter in self.LABEL_SEQ:
            line = f"{letter}. {row[letter].strip()}"
            lines.append(line)
        return '\n'.join(lines).strip()

    def get_answer_text(self, row: dict, label: int) -> str:
        letter = self.LABEL2TEXT[label]
        return row[letter]

    def get_answer_index(self, row: dict) -> int:
        return self.TEXT2LABEL[row["Answer"]]

    def get_fewshot_text(self, row: dict) -> str:
        subject = row["subject"]
        assert subject in self.fewshot_examples
        rows = self.fewshot_examples[subject][:self.num_shots]
        shots = list()
        for row in rows:
            question = self.get_question_text(row)
            answer = self.get_answer_text(row, label=self.get_answer_index(row))
            shot = self.SHOT_TEMPLATE.format(question=question, answer=answer)
            shots.append(shot)
        return "\n\n\n".join(shots)

    def extract_fewshot_examples(self) -> dict[str, list[dict]]:
        fewshot_examples = dict()
        for row in self.dataset["dev"]:
            subject = row["subject"]
            if subject in fewshot_examples:
                fewshot_examples[subject].append(row)
            else:
                fewshot_examples[subject] = [row]
        # Check that each subject has MAX_NUM_SHOTS shots
        for subject, rows in fewshot_examples.items():
            assert len(rows) == self.MAX_NUM_SHOTS
        return fewshot_examples

if __name__ == "__main__":
    bench = CMMLUBench()
    for time_step, row in enumerate(bench.get_dataset()):
        x = bench.get_input(row)
        print(x["prompt_zeroshot"], end="\n\n\n==========\n")
        print(x["prompt_cot"], end="\n\n\n==========\n")
        print(x["prompt_fewshot"], end="\n\n\n==========\n")
        print(x["parse_template"], end="\n\n\n==========\n")
        if time_step == 0:
            break

