import re
import random
import textwrap
import evaluate
from datasets import Dataset

from stream_bench.benchmarks.base import Bench

class MathQA(Bench):
    """
    MathQA: Towards Interpretable Math Word Problem Solving with Operation-Based Formalisms
    Aida Amini, Saadia Gabriel, Shanchuan Lin, Rik Koncel-Kedziorski, Yejin Choi, Hannaneh Hajishirzi
    """
    DATASET_PATH = "math_qa"

    LABEL2TEXT = {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e'}
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}
    NOTINLABEL = len(LABEL2TEXT)
    LABEL_SEQ = ['a', 'b', 'c', 'd', 'e']
    LABEL_SET = set(LABEL_SEQ)

    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    # NOTE: Currently the prompt templates are 100% the same  as the ones in mmlu.py (Prompt formats adapted from https://github.com/openai/evals/blob/main/examples/mmlu.ipynb)
    INSTRUCTION = "Answer the following Multiple-Choice Question."
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    {{choices}}
    Answer (generate the rationale before providing the final answer):""")
    # Zero-shot chain of thought
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    Answer (generate the rationale before providing the final answer):""")
    # Few-shot
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}
    Answer options are a, b, c, d, e
    
    Here are some example cases.
    
    {{{{fewshot_text}}}}
    Now answer the following case.
    
    {{question}}
    {{choices}}
    Answer (generate the rationale before providing the final answer):""")
    # Shot template
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    {{choices}}
    Answer (generate the rationale before providing the final answer): {{answer}}""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{{{model_output}}}}

    Convert the model output into one of the following options (one option per line):
    {{choices}}

    Answer (generate the rationale before providing the final answer):""")

    def __init__(
        self,
        split: str = "validation",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        num_shots: int = 16,
        **kwargs
    ) -> None:
        super().__init__({})
        self.split = split
        self.seed = int(seed)
        self.feedback = feedback
        self.num_shots = num_shots
        self.fewshot_examples = self.extract_fewshot_examples()

    def get_dataset(self) -> Dataset:
        return self.dataset[self.split].shuffle(seed=self.seed)

    def parse_answer(self, text):
        matches = [
            r'nswer is approximately ([a-e])',
            r'the closest option is ([a-e])',
            r'final answer is ([a-e])',
            r'answer is most likely ([a-e])',
            r'the answer is ([a-e])',
            r'Answer: ([a-e]).',
            r'answer is\*\*([a-e])',
            r'answer is ([a-e])',
            r'ANSWER IS \*\*([a-e])',
            r'ANSWER IS\*\*([a-e])',
            r'## ANSWER: \n\n\*\*([a-e])',
            r'## ANSWER: ([a-e])',
            r'Answer: ([a-e])',
            r'nswer is \*\*([a-e])\*\*.'
            r'## ([a-e]).',
            r'## ([a-e])',
            r'([a-e]).',
        ]
        for match_re in matches:
            if re.findall(match_re, text):
                return re.findall(match_re, text)[0].strip()
        return text

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = self.parse_answer(res.lower().strip())
        if res not in self.LABEL_SET:
            prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        question = self.get_question_text(row)
        prediction = self.postprocess_generation(res=model_output, idx=-1)
        if prediction in self.LABEL2TEXT:
            self_output = self.get_answer_text(row, prediction)
        else:
            print(model_output)
            print(prediction, self.LABEL2TEXT, row['options'])
            print(f"Prediction not in the label set. Randomly sample a label as self output...")
            random_idx = random.sample(range(len(self.LABEL_SET)), k=1)[0]
            self_output = self.get_answer_text(row, random_idx)
        ground_truth = self.get_answer_text(row, self.TEXT2LABEL[row["correct"]])
        if self.feedback == "no_user_feedback":
            return False, {"question": question, "self_output": self_output, "shot_template": self.SHOT_TEMPLATE}
        elif self.feedback == "ground_truth":
            return True, {"question": question, "self_output": self_output, "ground_truth": ground_truth, "shot_template": self.SHOT_TEMPLATE}
        raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        """Return the baseline prompt and input fields for serving as the agent's input."""
        row_input = {key: row[key] for key in ["Problem", "Rationale", "options"]}
        question, fewshot_text = self.get_question_text(row), self.get_fewshot_text()
        choices = self.get_choices_text(row)
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(question=question, choices=choices)
        row_input["prompt_cot"] = self.PROMPT_COT.format(question=question)
        row_input["prompt_fewshot"] = self.FEWSHOT_TEMPLATE.format(question=question, choices=choices).format(fewshot_text=fewshot_text)
        row_input["parse_template"] = self.PROMPT_PARSE.format(choices=self.get_choices_text(row))
        row_input["label_set"] = self.LABEL_SET
        row_input["question"] = question
        row_input["fewshot_template"] = self.FEWSHOT_TEMPLATE.format(question=question, choices=choices)
        return row_input

    def get_output(self, row: dict) -> int:
        assert row["correct"] in self.LABEL_SET

        return self.TEXT2LABEL[row["correct"]]

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics


    def process_results(self, prediction: int, label: int, return_details: bool = False, **kwargs) -> bool | dict:
        accuracy = evaluate.load("accuracy")
        correct = prediction == label

        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions, references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_question_text(self, row: dict) -> str:
        return row["Problem"].strip()

    def get_choices_text(self, row: dict) -> str:
        return row['options']

    def get_answer_text(self, row: dict, predict: dict=None) -> str:
        labels = []
        all_choices = []
        if isinstance(row['options'], str):
            if '[' in row['options']:
                options = eval(row['options'])
            else:
                options = row['options'].split(' , ')
        elif isinstance(row['options'], list) and len(row['options']) == 1:
            options = row['options'][0]
            options = options.split(' , ')
        else:
            options = row['options']

        for choices in options:
            try:
                if ' ) ' not in choices:
                    print(options)
                    # ['a ) 2', '3,4', 'b ) 1', '3,5', 'c ) 2', '5,6', 'd ) 4', '8,9', 'e ) 12', '14,16']
                    continue
                label, choice = choices.split(' ) ')
                labels.append(label)
                all_choices.append(choice)
            except ValueError as e:
                print(e)
                print(options)
        if predict is None:
            label = self.TEXT2LABEL[row["correct"]]
        else:
            if isinstance(predict, int):
                label = predict
            else:
                label = self.TEXT2LABEL[predict]

        key = labels[label]
        value = all_choices[label]
        rationale = row['Rationale']
        return f"Rationale: {rationale}\nSo final answer is {key}. {value}".strip('" \n').strip()

    def get_fewshot_text(self) -> str:
        rows = self.fewshot_examples
        shots = list()
        for row in rows:
            question = self.get_question_text(row)
            answer = self.get_answer_text(row)
            choices = self.get_choices_text(row)
            shot = self.SHOT_TEMPLATE.format(question=question, choices=choices, answer=answer)
            shots.append(shot)
        return "\n\n\n".join(shots).strip('" \n').strip()

    def extract_fewshot_examples(self) -> list[dict[str, str]]:
        """Extract few-shot examples from the training sets of MedQA."""
        fewshot_pool = self.dataset["train"].shuffle(seed=self.seed)
        fewshot_examples = list()
        for i in range(self.num_shots):
            row = fewshot_pool[i]
            fewshot_examples.append(row)
        return fewshot_examples



if __name__ == "__main__":
    # def print_prompts(bench: Bench) -> None:
    #     row = bench.get_dataset()[0]
    #     x = bench.get_input(row)
    #     print(x["prompt_zeroshot"], end="\n\n\n==========\n")
    #     print(x["prompt_cot"], end="\n\n\n==========\n")
    #     print(x["prompt_fewshot"], end="\n\n\n==========\n")
    #     print(x["parse_template"], end="\n\n\n==========\n")

    usmle = MathQA()
    print(usmle.TEXT2LABEL)
    # print_prompts(usmle)
    rationales = ["Rationale: 'The average monthly balance is 1.1 * last day balance = 1.1 * $5080 = $5598. The number of months in a year is 12. So, the average monthly balance is $5598 / 12 = $466.57. However, since the answer options are given in whole numbers, we need to find the closest option. The closest option to $466.57 is $460. Therefore, the answer is likely to be one of the options close to $460. Let's check the options: a) 2840 is too low, b) 5680 is too high, c) 6840 is close but still a bit high, d) 25400 is much too high, e) 28400 is much too high. Based on this analysis, the answer is most likely d) ",
                  "or the computer science department, there are 12 candidates, so the number of combinations is c(12, 2) = 66. since no candidate is eligible for a position in both departments, the total number of different sets of 3 candidates is the product of the number of combinations from each department. final answer: 8 * 66 = 528\"\n\nso final answer is d. 528."]
    for rationale in rationales:
        output = usmle.postprocess_generation(rationale, 0)
        print(output)
    # for row in usmle.get_dataset():
    #     print(row['choices']['label'])