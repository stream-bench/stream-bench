import sys
import textwrap
sys.path.append("../WebShop")
import gym
import importlib
importlib.import_module("web_agent_site.envs")
import numpy as np
from web_agent_site.utils import DEFAULT_FILE_PATH
from stream_bench.benchmarks.base import Bench
from stream_bench.benchmarks.utils import strip_all_lines

def format_observation(observation):
    indented_lines = ["  " + line for line in observation.splitlines()]
    return "\n".join(indented_lines)

def format_actions(action_history):
    try:
        recent_actions = action_history[-min(5, len(action_history)):]
        if recent_actions is None:
            return ""
        formatted_actions = ["- " + " ".join(action) for action in recent_actions]
        return "\n".join(formatted_actions)
    except TypeError:
        return ""

def format_available_actions(available_actions):
    formatted_available = ["- " + act for act in available_actions.splitlines()]
    return "\n".join(formatted_available)


class WebShop(Bench):
    DATASET_PATH = "appier-rey/webshop_remembered"
    
    BASE_PROMPT = textwrap.dedent("""\
        ---
        Last 5 Actions:
        {actions}
        Observation: |
        {observation}
        Available Actions:
        {available_actions}
        """)

    def __init__(self, feedback='no_user_feedback',
                 timeout=3.0,
                 agent=None,
                 file_path="",
                 reward_threshold=0.5,
                 mode='instruct', **kwargs):
        super().__init__({})
        self.dataset_split = kwargs['split']
        self.env = gym.make( "WebAgentTextEnv-v0",
                  observation_mode="text_rich",
                  file_path=(file_path if file_path is not None and file_path != ""
                                            else DEFAULT_FILE_PATH),
                  num_products=None,
                  human_goals=True,
                  num_prev_actions=0,
                  num_prev_obs=0,
                  )
        # variables : n_correct, references, predictions init in parent cls
        self.total_rewards = 0
        self.reward_threshold = reward_threshold
        self.total = 0
        self.steps_rewards = []
        self.steps_acc = []
        self.tracking_success = []
        # currently not used
        self.timestep_feedback = {}
        self.agent_callback = None
        if hasattr(agent, 'retrieve_experience'):
            self.agent_callback = agent.retrieve_experience

    def get_metrics(self):
        return {
            'acc_rewards': self.total_rewards,
            'n_correct': self.n_correct
        }

    def get_dataset(self):
        """
        Returns dataset for the task or an iterable of any object, 
        that get_prompt can handle
        """
        return self.dataset[self.dataset_split]

    def get_input(self, doc: dict, reference=None, feedback=None) -> dict:
        """
        Builds the prompt for the LM to generate from.
        """
        session_id = doc["session_id"]
        observation = self.env.reset(session=session_id)[0]
        task = self.env.get_instruction_text()
        available_actions = self.env.get_available_actions()["clickables"]

        return {
            "session_id": session_id,
            "observation": observation,
            "task": task,
            "available_actions": available_actions,
        }

    def verbalize_score(self, score, threshold):
        if score < threshold:
            return "You have not finish the task given by the instruction"
        elif score >= threshold:
            return "You have correctly finish the task given by the instruction"

    def process_results(self, prediction, row_output, return_details=False, simulate_env=False, time_step=-1):
        correct = prediction['success']
        self.timestep_feedback[prediction['session_id']] = self.verbalize_score(prediction['total_reward'],
                                                                                threshold=self.reward_threshold)

        if not simulate_env:
            self.tracking_success.append(int(correct))
            self.n_correct += int(correct)
            self.predictions.append(prediction)
            self.references.append(row_output)
            self.steps_acc.append(prediction['num_steps'])
            self.steps_rewards.append(prediction['total_reward'])            
            self.total_rewards += prediction['total_reward']
            self.total += 1

        rolling_acc = self.n_correct / max(self.total, 1)

        if return_details:
            return {
                'correct': correct,
                'n_correct': self.n_correct,
                'rolling_acc': np.mean(self.tracking_success),
                'acc_rewards': self.total_rewards,
                'avg_steps': np.mean(self.steps_acc),
                'avg_rewards': np.mean(self.steps_rewards),
            }
        return correct

    def give_feedback(self, model_output, row, pred_res):
        return True, {
            'feedback': self.timestep_feedback[row['session_id']]
        }

    def get_output(self, row):
        session_id = row['session_id']
        return { 'session': session_id, 'label': session_id }

    def postprocess_generation(self, model_output, time_step, **kwargs):
        return model_output

if __name__ == "__main__":
    # webshop = WebShop()
    env = gym.make( "WebAgentTextEnv-v0",
                    observation_mode="text_rich",
                    file_path=DEFAULT_FILE_PATH,
                    num_products=None,
                    human_goals=True,
                    num_prev_actions=0,
                    num_prev_obs=0,
                    )
    res = env.reset(session=0)
    print(res)