"""Evaluating Large Language Models Trained on Code
https://arxiv.org/abs/2107.03374

The HumanEval dataset released by OpenAI includes 164 programming problems with a function signature,
docstring, body, and several unit tests.
They were handwritten to ensure not to be included in the training set of code generation models.

Homepage: https://github.com/openai/human-eval
"""
import re
from tqdm import tqdm
from .base import Bench
from .humaneval_utils.evaluate import compute_code_eval

four_space_tab = "    "

def fix_tab_indents(text: str) -> str:
    return text.replace("\t", four_space_tab)

def extract_code(text):
    pattern = r'```(?:python)?\s*(.*?)```?'
    code_blocks = re.findall(pattern, text, re.DOTALL)
    return code_blocks

def instruct_prompt(prompt: str) -> str:
    return f"""Below is an instruction that describes a task. Write a response that appropriately completes the request.\n\n### Instruction:\nComplete the following Python code without any tests or explanation\n{prompt}\n\n### Response:"""

def standard_prompt(prompt: str) -> str:
    return f"""Complete the following Python code without any tests or explanation\n{prompt}"""


def write_prompt(prompt: str) -> str:
    return f"""Write a Python program to complete the following code:\n{prompt}"""


def replit_glaive_prompt(prompt: str) -> str:
    return f"""Below is an instruction that describes a task, paired with an input that provides further context.\n Write a response that appropriately completes the request.\n\n ### Instruction:\nWrite a program to perform the given task.\n\n Input:\n{prompt}\n\n### Response:"""

def create_all_tasks():
    """Creates a dictionary of tasks from a list of levels
    :return: {task_name: task}
        e.g. {multiple-py: Task, multiple-java: Task}
    """
    return {"humaneval": create_task(True), "humaneval-unstripped": create_task(False)}


def create_task():

    class HumanEval(GeneralHumanEval):
        DATASET_PATH = 'openai_humaneval'
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    return HumanEval

def create_task_streaming():
    class StreamingHumanEval(GeneralHumanEval):
        DATASET_PATH = 'appier-ai-research/humaneval'
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    return StreamingHumanEval

class GeneralHumanEval(Bench):
    """A task represents an entire benchmark including its dataset, problems,
    answers, generation settings and evaluation methods.
    """

    def __init__(self, strip_prompt=False,
                 k=[1, 10, 100],
                 num_workers=16,
                 feedback='no_user_feedback',
                 timeout=3.0,
                 agent=None,
                 mode='instruct', **kwargs):
        super().__init__(config={})
        assert mode in ['instruct', 'write','replit-glaive','standard']
        # outsource this to yaml attribute
        if mode == 'instruct':
            self.prompt_wrapper = instruct_prompt
        elif mode == 'write':
            self.prompt_wrapper = write_prompt
        elif mode =='replit-glaive':
            self.prompt_wrapper = replit_glaive_prompt
        elif mode =='standard':
            self.prompt_wrapper = standard_prompt
        self.feedback = feedback
        self.strip_prompt = strip_prompt
        self.k = k
        self.total = 0
        self.num_workers = num_workers
        self.timeout = timeout
        self.agent_callback = None
        if hasattr(agent, 'retrieve_experience'):
            self.agent_callback = agent.retrieve_experience

    def evaluate(self, agent):
        # TODO: delete later
        for time_step, row in enumerate(tqdm(self.dataset, dynamic_ncols=True)):
            x = self.get_input(row)
            model_output = agent(x)
            feedback = self.give_feedback(model_output, row)
            agent.process_feedback(feedback)

    def get_dataset(self):
        """Returns dataset for the task or an iterable of any object, that get_prompt can handle"""
        return self.dataset["test"]

    def get_input(self, doc: dict, reference=None, feedback=None) -> dict:
        """Builds the prompt for the LM to generate from."""
        prompt = doc["prompt"]
        if self.strip_prompt:
            prompt = doc["prompt"].strip()
        instruction = self.prompt_wrapper(prompt)
        if reference is not None:
            instruction = instruction + "\n" + reference
        if feedback is not None:
            instruction = "Here are some reference material:\n"+ feedback + "\n\n"+ instruction
        elif self.agent_callback is not None:
            feedback = self.agent_callback(doc)
            instruction = "Here are some reference material:\n"+ feedback + "\n\n"+ instruction
        doc['prompt'] = instruction
        doc['raw_prompt'] = doc
        return doc

    def get_output(self, doc):
        return self.get_reference(doc)

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:

        if self.feedback == "weak_feedback":
            prediction = self.postprocess_generation(model_output, row['time_step'])
            results, execution_res = compute_code_eval(
                references=[self.get_output(row)],
                predictions=[[prediction]],
                k=[1],
                num_workers=self.num_workers,
                timeout=self.timeout,
            )
            values = list(execution_res.values())[0][0][1]
            feedback_msg = prediction + '\n'+ 'results: {}'.format(values['result'])
            return (True, {"feedback_msg": feedback_msg, "generated_code": prediction})
        elif self.feedback == "ground_truth":
            feedback_msg = row['prompt']+'\n'+row['canonical_solution']
            return (True, {"feedback_msg": feedback_msg })
        else:
            return (False, {"feedback_msg" : "None" })
    def get_reference(self, doc):
        """Builds the reference solution for the doc (sample from the test dataset)."""
        test_func = doc["test"]
        entry_point = f"check({doc['entry_point']})"
        return "\n" + test_func + "\n" + entry_point


    def postprocess_generation(self, generation, idx):
        """Defines the postprocessing for a LM generation.
        :param generation: str
            code generation from LM
        :param idx: int
            index of doc in the dataset to which the generation belongs
            (not used for Humaneval-Task)
        """
        if '### Instruction' in generation or 'Python' in generation:
            prompt = self.get_input(self.dataset["test"][idx])
            generation = generation[len(prompt) :]
        if '```' in generation:
            if generation.count('```') >= 2:
                results = extract_code(generation)
                if len(results):
                    generation = results[0]
            elif generation[:3] == '```':
                generation = generation.split('\n', maxsplit=1)[-1]
            # handle this weird case, since if there's a white space extract_code will remove it
            # ```python
            #     music = {'hi': 'hi'}
            #     return true
            # ```
        prepend_tab = False
        if 'def ' not in generation and \
            four_space_tab+'return' in generation and \
            four_space_tab != generation[:4] and \
            generation[:4] not in ('from', 'import'):
            generation = four_space_tab+generation
            prepend_tab = True

        if (four_space_tab != generation[:4] or four_space_tab*2 not in generation) and \
            generation[:3] != 'def' and not prepend_tab and \
            generation[:4] not in ('from', 'import'):
            generation = four_space_tab+'\n    '.join(generation.split('\n'))
        entry_function = self.dataset["test"][idx]['entry_point']
        if 'def '+entry_function+'(' not in generation:
            generation = self.dataset["test"][idx]['prompt'] + '\n' + generation
        return generation

    def process_results(self, generations, references, return_details=False, simulate_env=False,**kwargs):
        """Takes the list of LM generations and evaluates them against ground truth references,
        returning the metric for the generations.
        :param generations: list(list(str))
            list of lists containing generations
        :param references: list(str)
            list of str containing refrences
        """
        assert isinstance(references, str)
        assert isinstance(generations, str)

        results, execution_res = compute_code_eval(
            references=[references],
            predictions=[[generations]],
            k=self.k,
            num_workers=self.num_workers,
            timeout=self.timeout,
        )
        correct = results['pass@1'] == 1.0
        if not simulate_env:
            self.n_correct += int(correct)
            self.predictions.append(generations)
            self.references.append(references)
            self.total += 1
        rolling_acc = self.n_correct / self.total

        if return_details:
            return {
                'correct': correct,
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_metrics(self):
        return {
            'pass@1': self.n_correct / self.total
        }
