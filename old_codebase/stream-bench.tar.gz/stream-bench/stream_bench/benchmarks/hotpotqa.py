import re
import string
from typing import Tuple
import gym
import textwrap
from datasets import load_dataset, Dataset
from langchain_community.docstore import Wikipedia
from langchain.agents.react.base import DocstoreExplorer
from stream_bench.benchmarks.base import Bench
from stream_bench.benchmarks.hotpot_utils.prompts import zeroshot_cot_agent_prompt
from stream_bench.benchmarks.hotpot_utils.fewshots_examples import COT
from stream_bench.benchmarks.utils import strip_all_lines

def parse_action(string):
    string = string.replace('**','')
    if 'Answer: ' in string:
        return 'Finish', string.split('Answer: ')[-1].replace('.', '').strip()

    pattern = r'(?:(\w+)|Finish)\[(.+)\]'
    match = re.search(pattern, string)
    if match:
        action_type = match.group(1) if match.group(1) else 'Finish'
        argument = match.group(2)
        return action_type, argument
    else:
        return None, None

def normalize_answer(s):
  def remove_articles(text):
    return re.sub(r"\b(a|an|the)\b", " ", text)
  
  def white_space_fix(text):
      return " ".join(text.split())

  def remove_punc(text):
      exclude = set(string.punctuation)
      return "".join(ch for ch in text if ch not in exclude)

  def lower(text):
      return text.lower()

  return white_space_fix(remove_articles(remove_punc(lower(s))))

def EM(answer, key) -> bool:
    if answer is None:
        return False
    return normalize_answer(answer) == normalize_answer(key)

class HotpotQA(Bench):
    DATASET_NAME = "fullwiki"
    DATASET_PATH = "hotpot_qa"
    # few shot sizes
    NUM_SHOTS = 16

    def __init__(self,
        split: str = "validation",
        seed: int = 0,
        feedback: str = "correctness",
        # max_steps: int = 6,
        **kwargs
    ):
        super().__init__({})
        self.split = split
        self.seed = seed
        self.feedback = feedback
        # self.max_steps = max_steps
        self.explorer = DocstoreExplorer(Wikipedia())
        self.total = 0
        self.fewshot_text = self.get_fewshot_text()
        self.reset()

    def get_dataset(self) -> Dataset:
        return load_dataset('hotpot_qa',
                            'fullwiki',
                            split=self.split+'[:1500]'
                        ).shuffle(self.seed)

    def reset(self):
        self.curr_step = 0
        self.terminated = False
        self.answer = ''

    def step(self, action: str) -> Tuple[str, bool, bool, bool, bool]:
        action_type, argument = parse_action(action)

        if action_type == 'Finish':
            self.answer = argument
            if self.is_correct():
                observation = 'Answer is CORRECT'
            else: 
                observation = 'Answer is INCORRECT'
            self.terminated = True

        elif action_type == 'Search':
            try:
                observation = self.explorer.search(argument).strip('\n').strip()
            except Exception as e:
                print(e)
                observation = f'Could not find that page, please try again.'
                    
        elif action_type == 'Lookup':
            try:
                observation = self.explorer.lookup(argument).strip('\n').strip()
            except ValueError:
                observation = f'The last page Searched was not found, so you cannot Lookup a keyword in it. Please try one of the similar pages given.'

        else:
            observation = 'Invalid Action. Valid Actions are Lookup[<topic>] Search[<topic>] and Finish[<answer>].'

        reward = self.is_correct()
        terminated = self.is_terminated()
        truncated = self.is_truncated()

        self.curr_step += 1

        return observation, reward, terminated, truncated, self.curr_step

    def is_correct(self) -> bool:
        return EM(self.answer, self.key)
    
    def is_terminated(self) -> bool:
        return self.terminated

    def is_truncated(self) -> bool:
        return self.curr_step >= self.max_steps
    @staticmethod
    def get_support_para(row):
        supporting_articles = row['supporting_facts']['title']
        articles = row['context']['title']
        sentences = row['context']['sentences'] 
        supporting_paragraphs = []
        for article in supporting_articles:
            supporting_paragraph = []
            for match_act, sentence in zip(articles, sentences):
                key = ''.join(sentence)
                if match_act == article and key not in supporting_paragraph:
                    supporting_paragraph.append(key)
            supporting_paragraph = ''.join(supporting_paragraph)
            supporting_paragraphs.append(supporting_paragraph)
        supporting_paragraphs = '\n\n'.join(supporting_paragraphs)
        return supporting_paragraphs

    def get_input(self, row: dict) -> dict:
        row_input = dict()
        supporting_paragraphs = self.get_support_para(row)
        question = row['question']
        row_input["question"] = question
        row_input["supporting_para"] = self.get_support_para(row)
        row_input["prompt_zeroshot"] = self.get_zeroshot_prompt(question, supporting_paragraphs)
        row_input["prompt_fewshot"] = self.get_fewshot_prompt(question, supporting_paragraphs)
        row_input["prompt_cot"] = self.get_cot_prompt(question, supporting_paragraphs)
        row_input["fewshot_template"] = self.get_fewshot_template(question, supporting_paragraphs)
        row_input["feedback_template"] = self.get_feedback_template(question, supporting_paragraphs)
        row_input["refine_template"] = self.get_refine_template(question, supporting_paragraphs)
        return row_input

    def get_output(self, row: dict):
        return {"label": row['answer']}

    def get_metrics(self):
        return {
            "EM": self.n_correct / self.total
        }

    def postprocess_generation(self, model_output, time_step=0):
        action_type, argument = parse_action(model_output)
        return argument        

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        action_type, argument = parse_action(model_output)
        correct = EM(argument, row['answer'])
        feedbacks = {
            "question": "Relevant Context: {}\nQuestion:{}".format(
                self.get_support_para(row).strip(),
                row["question"]
            ),
            "self_output": argument,
            "is_correct": correct,
            "ground_truth": row["answer"],
            "shot_template": self.get_shot_template(),
            "memprompt_template": self.get_memprompt_template()
        }
        return True, feedbacks

    def process_results(self, generations: str, label: dict, return_details: bool = False, **kwargs):
        """Takes the list of LM generations and evaluates them against ground truth references,
        returning the metric for the generations.
        :param generations: list(list(str))
            list of lists containing generations
        :param labels: original labels
            list of str containing refrences
        """
        correct = EM(generations, label['label'])
        self.n_correct += correct
        self.predictions.append(generations)
        self.references.append(label['label'])
        self.total += 1
        rolling_acc = self.n_correct / self.total
        if return_details:
            return {
                "result": 'Answer is Correct' if correct == 1 else 'Answer is NOT Correct',
                "correct": correct,
                "n_correct": self.n_correct,
                "rolling_acc": rolling_acc
            }
        return correct

    @staticmethod
    def get_cot_prompt(question, supporting_para):
        return zeroshot_cot_agent_prompt.format(
            question=question,
            context=supporting_para,
            scratchpad='',
            reflections=''
        )

    @staticmethod
    def get_shot_template() -> str:
        # key from feedback, so you have to make sure the question key
        # from feedback match it
        # question already include relevant context, question
        return strip_all_lines(textwrap.dedent(f"""\
        {{question}}
        Answer: {{answer}}"""))


    @staticmethod
    def get_memprompt_template() -> str:
        # key from feedback, so you have to make sure the question key
        # from feedback match it
        # question already include relevant context, question
        prompt = textwrap.dedent(f"""\
        {{question}}
        Your answer: {{answer}}
        User Feedback: {{correctness}}""")
        return strip_all_lines(prompt)

    @staticmethod
    def get_zeroshot_prompt(question: str, supporting_para: str):
        return strip_all_lines(textwrap.dedent(f"""\
        You are tasked to solve a question answering task based on a relevant context
        Give your answer in Finish[answer] format.
            - For example who is the president of US, you must answer in Finish[Joe Biden]
        You will be given context that you should use to help you answer the question.
        Relevant Context: {supporting_para}
        Question: {question}
        Your answer must follow the following format: Finish[your answer to the question qa]"""))


    @staticmethod
    def get_feedback_template(
        question: str,
        supporting_para: str
        ) -> str:
        prompt = textwrap.dedent(f"""\
        You are tasked to solve a question answering task based on a relevant context
        Give your answer in Finish[answer] format.
            - For example who is the president of US, you must answer in Finish[Joe Biden]
        Relevant Context: {supporting_para}
        Question: {question}
        Your answer : {{y_hat}}
        First, determine whether you need to refine your answer in terms of its correctness.
        If you consider that your answer is correct, output 'NO NEED TO REFINE' in uppercase.
        Otherwise, provide a suggestion to correct answer in the following format: Finish[your answer]""")
        return strip_all_lines(prompt)

    @staticmethod
    def get_refine_template(
        question: str,
        supporting_para: str
        ) -> str:
        prompt = textwrap.dedent(f"""\
        You are tasked to solve a question answering task based on a relevant context
        Give your answer in Finish[answer] format.
            - For example who is the president of US, you must answer in Finish[Joe Biden]
        Relevant Context: {supporting_para}
        Question: {question}
        -- Your previous answer-feedback trajectory:
        {{trajectory}}
        
        According to the latest feedback, provide your new answer
        Provide your output in the following format: Finish[your answer]""")
        return strip_all_lines(prompt)
    
    @staticmethod
    def get_fewshot_template(
        question: str,
        supporting_para: str
    ) -> str:
        prompt = textwrap.dedent(f"""\
        You are tasked to solve a question answering task based on a relevant context
        Give your answer in Finish[answer] format.
            - For example who is the president of US, you must answer in Finish[Joe Biden]        
        Here are some examples:
        {{fewshot_text}}
        (END OF EXAMPLES)
        
        Now it's your turn.
        
        Relevant Context: {supporting_para} 
        Question: {question}
        make sure to follow this format: Finish[your answer]""")
        return strip_all_lines(prompt)

    def get_fewshot_text(self) -> str:
        dataset = load_dataset('hotpot_qa', 'fullwiki')['train']
        example = []
        for row in dataset:
            supported_ac = HotpotQA.get_support_para(row)
            example.append('Related Context: {}\nQuestion: {}\nAnswer: Finish[{}]\n\n'.format(
                supported_ac,
                row['question'],
                row['answer']
            ))
            # yeah I know it hurts
            if len(example) >= self.NUM_SHOTS:
                break
        print(len(example))
        shots = example[:self.NUM_SHOTS]
        return "\n\n\n".join(shots).replace("\\", "\\\\")
    # bruh
    def get_fewshot_prompt(
        self,
        question: str,
        supporting_para: str
    ) -> str:
        fewshot_template = self.get_fewshot_template(question, supporting_para)
        return re.sub(r"\{fewshot_text\}", self.fewshot_text, fewshot_template)


if __name__ == "__main__":
    dataset = load_dataset('hotpot_qa', 'fullwiki')['train']
    example = []
    for row in dataset:
        supported_ac = HotpotQA.get_support_para(row)
        example.append('Related Context: {}\nQuestion: {}\nAnswer: Finish[{}]\n\n'.format(
            supported_ac,
            row['question'],
            row['answer']
        ))
        if len(example) > 16:
            break
    for idx in range(16):
        print(example[idx])
