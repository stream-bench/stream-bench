import textwrap
import evaluate
from datasets import Dataset

from stream_bench.benchmarks.base import Bench

class MMLULawBench(Bench):
    DATASET_PATH = "cais/mmlu"
    DATASET_NAME = "professional_law"

    LABEL2TEXT = {0: 'A', 1: 'B', 2: 'C', 3: 'D'}
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}
    NOTINLABEL = len(LABEL2TEXT)
    LABEL_SET = {'A', 'B', 'C', 'D'}
    LABEL_SEQ = ['A', 'B', 'C', 'D']

    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    # Prompt format reference: https://github.com/openai/evals/blob/main/examples/mmlu.ipynb
    INSTRUCTION = "Answer the following Multiple-Choice Question."
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    {{choices}}
    Answer (please only answer with a single letter):""")
    # Zero-shot chain of thought
    PROMPT_COT = textwrap.dedent(f"""\
    {INSTRUCTION}

    {{question}}
    {{choices}}
    Answer (generate the rationale before providing the final answer):""")
    # Few-shot
    PROMPT_FEWSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}

    Here are some example cases.
    
    {{fewshot_text}}
    
    Now answer the following case.
    
    {{question}}
    {{choices}}
    Answer:""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{{{model_output}}}}
    
    Convert the model output into one of the following options (one option per line):
    {{choices}}
    
    Answer (please only answer with a single letter):""")

    def __init__(
        self,
        split: str = "validation",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        **kwargs
    ) -> None:
        super().__init__({})
        print("Finish loading the MMLU dataset.")
        self.split = split
        self.seed = seed
        self.feedback = feedback
        self.fewshot_examples = self.extract_fewshot_examples()

    def get_dataset(self) -> Dataset:
        return self.dataset[self.split].shuffle(seed=self.seed)

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        if self.feedback == "no_user_feedback":
            return False, {"feedback_msg": "None"}
        elif self.feedback == "ground_truth":
            raise NotImplementedError
        raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        """Return the baseline prompt and input fields for serving as the agent's input."""
        row_input = {key: row[key] for key in ["subject", "question", "choices"]}
        question, choices, fewshot_text = row["question"], self.get_choices_text(row["choices"]), self.get_fewshot_text(subject=row["subject"])
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(question=question, choices=choices)
        row_input["prompt_cot"] = self.PROMPT_COT.format(question=question, choices=choices)
        row_input["prompt_fewshot"] = self.PROMPT_FEWSHOT.format(fewshot_text=fewshot_text, question=question, choices=choices)
        row_input["parse_template"] = self.PROMPT_PARSE.format(choices=choices)
        row_input["label_set"] = self.LABEL_SET
        return row_input

    def get_output(self, row: dict) -> int:
        return row["answer"]

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = res.upper().strip()
        if res not in self.LABEL_SET:
            prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def process_results(self, prediction: int, label: int, return_details: bool = False) -> bool | dict:
        accuracy = evaluate.load("accuracy")
        correct = prediction == label

        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions, references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_choices_text(self, choices: list[str]) -> str:
        assert len(self.LABEL_SEQ) == len(choices)
        lines = list()
        for label, choice_text in zip(self.LABEL_SEQ, choices):
            lines.append(f"{label}. {choice_text}")
        return '\n'.join(lines)

    def get_fewshot_text(self, subject: str, k: int = 5) -> str:
        """In MMLU, the default maximum number of exemplars is k = 5.

        Format: (each shot is delimited by triple newlines)
        {{question}}
        {{choices}}
        Answer:
        """
        assert subject in self.fewshot_examples
        rows = self.fewshot_examples[subject][:k]
        shots = list()
        for row in rows:
            question = row["question"]
            choices = self.get_choices_text(row["choices"])
            answer = f'Answer: {self.LABEL2TEXT[row["answer"]]}. {row["choices"][row["answer"]]}'
            shot = '\n'.join([question, choices, answer])
            shots.append(shot)
        return "\n\n\n".join(shots)

    def extract_fewshot_examples(self) -> dict[str, list[dict]]:
        """Extract few-shot examples from the dev set of MMLU.

        Returns:
            dict[str, list[dict]]: Key is row["subject"], value is the 5-shot examples
        """
        fewshot_examples = dict()
        for row in self.dataset["dev"]:
            subject = row["subject"]
            if subject in fewshot_examples:
                fewshot_examples[subject].append(row)
            else:
                fewshot_examples[subject] = [row]
        # Check that each subject has 5 shots
        for subject, rows in fewshot_examples.items():
            assert len(rows) == 5
        return fewshot_examples


