from .base import Bench
from .anli import ANLIBench
from .tmmluplus import TMMLUPlus
from .humaneval import create_task, create_task_streaming
from .text_to_sql import create_bird, create_cosql, create_spider
from .mmlu import MMLUBench
from .math_qa import MathQA
from .mmlu_law import MMLULawBench
from .multifin import MultiFinENBench, MultiFinESBench
from .medqa import MedQAUSMLEBench, MedQAMCMLEBench, MedQATWMLEBench
from .ds_1000 import DS1000
from .aiarc import ArcBench
has_web = False
try:
    from .webshop import WebShop
    has_web = True
except ImportError as e:
    print('webshop not supported because module is not installed', str(e))
# from .tweeteval import TweetEvalBench
from .cmmlu import CMMLUBench
from .toolbench import ToolBench
from .ddxplus import create_ddxplus
from .hotpotqa_distract import HotpotQADistract

classes = locals()

TASKS = {
    "arc": ArcBench,
    'anli': ANLIBench,
    'humaneval': create_task(),
    'humaneval_extended': create_task_streaming(),
    'cosql': create_cosql(),
    'bird': create_bird(),
    'tmmluplus': TMMLUPlus,
    'spider': create_spider(),
    'ds_1000': DS1000,
    'math_qa': MathQA,
    'mmlu': MMLUBench,
    'mmlu_law': MMLULawBench,
    'multifinen': MultiFinENBench,
    'multifines': MultiFinESBench,
    'medqa_usmle': MedQAUSMLEBench,
    'medqa_mcmle': MedQAMCMLEBench,
    'medqa_twmle': MedQATWMLEBench,
    'cmmlu': CMMLUBench,
    'toolbench': ToolBench,
    'ddxplus': create_ddxplus(),
    'hotpotqa_distract': HotpotQADistract
}
if has_web:
    TASKS['webshop'] = WebShop

def load_benchmark(benchmark_name) -> Bench:
    if benchmark_name in TASKS:
        return TASKS[benchmark_name]
    if benchmark_name in classes:
        return classes[benchmark_name]

    raise ValueError("Benchmark %s not found" % benchmark_name)
