import random
import textwrap
import evaluate
from typing import Any
from datasets import Dataset

from stream_bench.benchmarks.base import Bench

class MultiFinENBench(Bench):
    DATASET_PATH = "TheFinAI/flare-multifin-en"
    DATASET_NAME = ""

    LABEL2TEXT = {
        0: "Finance",
        1: "Technology",
        2: "Tax & Accounting",
        3: "Business & Management",
        4: "Government & Controls",
        5: "Industry"
    }
    NOTINLABEL = len(LABEL2TEXT)
    TEXT2LABEL = {v.lower(): k for k, v in LABEL2TEXT.items()}
    LABEL_SET = {v.lower() for v in LABEL2TEXT.values()}

    # We provide the following baseline prompt templates for inference. Feel free to use your own prompt in your agent.
    INSTRUCTION = "In this task, you're working with English headlines from the MULTIFIN dataset. This dataset is made up of real-world article headlines from a large accounting firm's websites. Your objective is to categorize each headline according to its primary topic. Your response should only include the category that best fits the headline. The potential categories are as follows (one option per line):"
    OPTIONS = "\n    ".join(LABEL2TEXT.values())  # NOTE: the four spaces are necessary for textwrap.dedent() formatting
    # Standard zero-shot
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Headline: {{text}}
    Answer (please only answer with a single option):""")
    # Few-shot template
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}
    
    Here are some example cases.
    
    {{{{fewshot_text}}}}
    
    Now answer the following case.
    
    {{question}}
    Answer:""")
    # Question template
    QUESTION_TEMPLATE = textwrap.dedent(f"""\
    Headline: {{text}}""")
    # Shot template
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    Answer: {{answer}}""")
    # Prompt for parsing the outputs for mapping to the label space
    PROMPT_PARSE = textwrap.dedent(f"""\
    Model output: {{model_output}}
    
    Convert the model output into one of the following options (one option per line):
    {OPTIONS}
    
    Answer (please only answer with a single option):""")

    def __init__(
        self,
        split: str = "test",
        seed: int = 0,
        feedback: str = "no_user_feedback",
        num_shots: int = 16,
        **kwargs
    ) -> None:
        super().__init__({})
        print("Finish loading the MultiFinEN dataset.")
        self.split = split
        self.seed = int(seed)
        self.feedback = feedback
        self.num_shots = num_shots
        dataset = self.dataset[self.split]
        dataset_dict = dataset.train_test_split(train_size=num_shots / len(dataset), shuffle=True, seed=self.seed)
        self.train_set = dataset_dict["train"]
        self.test_set = dataset_dict["test"]
        assert (len(self.train_set) == num_shots) and (len(self.train_set) + len(self.test_set) == len(dataset))

    def get_dataset(self) -> Dataset:
        return self.test_set

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        question = self.QUESTION_TEMPLATE.format(text=row["text"])
        prediction = self.postprocess_generation(res=model_output, idx=-1)
        if prediction in self.LABEL2TEXT:
            self_output = self.LABEL2TEXT[prediction]
        else:
            print(f"Prediction not in the label set. Randomly sample a label as self output...")
            self_output = random.sample(list(self.LABEL_SET), k=1)[0]
        assert self.LABEL2TEXT[row["gold"]] == row["answer"]
        ground_truth = row["answer"]
        if self.feedback == "no_user_feedback":
            return False, {"question": question, "self_output": self_output, "shot_template": self.SHOT_TEMPLATE}
        elif self.feedback == "ground_truth":
            return True, {"question": question, "self_output": self_output, "ground_truth": ground_truth, "shot_template": self.SHOT_TEMPLATE}
        raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        row_input = {key: row[key] for key in ["id", "query", "text", "choices"]}
        row_input["prompt_zeroshot"] = self.PROMPT_ZEROSHOT.format(text=row["text"])
        row_input["prompt_cot"] = None  # TODO
        row_input["prompt_fewshot"] = self.FEWSHOT_TEMPLATE.format(question=self.get_answer_text(row)).format(fewshot_text=self.get_fewshot_text())
        row_input["parse_template"] = self.PROMPT_PARSE
        row_input["question"] = self.QUESTION_TEMPLATE.format(text=row["text"])
        row_input["label_set"] = self.LABEL_SET
        row_input["fewshot_template"] = self.FEWSHOT_TEMPLATE.format(question=self.get_answer_text(row))
        return row_input

    def get_output(self, row: dict) -> int:
        assert row["answer"] == self.LABEL2TEXT[row["gold"]]
        return row["gold"]

    def get_metrics(self) -> dict:
        accuracy = evaluate.load("accuracy")
        metrics = accuracy.compute(predictions=self.predictions, references=self.references)
        return metrics

    def postprocess_generation(self, res: str, idx: int) -> int:
        """Parse the LLM's response into the label."""
        res = res.lower().strip()
        if res not in self.LABEL_SET:
            prediction = self.NOTINLABEL
        else:
            prediction = self.TEXT2LABEL[res]
        return prediction

    def process_results(self, prediction: Any, label: Any, return_details: bool = False, **kwargs) -> bool | dict:
        """Takes the list of LM generations and evaluates them against ground truth references,
        returning the metric for the generations.
        :param generations: list(list(str))
            list of lists containing generations
        :param labels: original labels
            list of str containing refrences
        """
        accuracy = evaluate.load("accuracy")
        correct = prediction == label
        self.n_correct += correct
        self.predictions.append(prediction)
        self.references.append(label)
        rolling_acc = accuracy.compute(predictions=self.predictions,
                                       references=self.references)["accuracy"]

        if return_details:
            return {
                'correct': int(correct),
                'n_correct': self.n_correct,
                'rolling_acc': rolling_acc
            }
        return correct

    def get_fewshot_text(self) -> str:
        shots = list()
        for row in self.train_set:
            question = self.QUESTION_TEMPLATE.format(
                text=row["text"]
            )
            shot = self.SHOT_TEMPLATE.format(
                question=question,
                answer=row["answer"]
            )
            shots.append(shot)
        return "\n\n\n".join(shots)

    def get_question_text(self, row, **kwargs):
        return self.QUESTION_TEMPLATE.format(
                text=row["text"]
            )

    def get_answer_text(self, row):
        return row["answer"]

    def get_choices_text(self, row):
        return ''

class MultiFinESBench(MultiFinENBench):
    DATASET_PATH = "TheFinAI/flare-es-multifin"
    DATASET_NAME = ""

    LABEL2TEXT = {
        0: 'Negocios y Gestión',
        1: 'Finanzas',
        2: 'Gobierno y Control',
        3: 'Industria',
        4: 'Impuestos y Contabilidad',
        5: 'Tecnología'
    }
    NOTINLABEL = len(LABEL2TEXT)
    TEXT2LABEL = {v.lower(): k for k, v in LABEL2TEXT.items()}
    LABEL_SET = {v.lower() for v in LABEL2TEXT.values()}

    # Proporcionamos las siguientes plantillas de mensajes base para la inferencia. Siéntase libre de usar su propio mensaje en su agente.
    INSTRUCTION = "En esta tarea, estás trabajando con titulares en español del dataset MULTIFIN. Este conjunto de datos está compuesto por titulares de artículos del mundo real de sitios web de una gran firma de contabilidad. Tu objetivo es categorizar cada titular según su tema principal. Tu respuesta solo debe incluir la categoría que mejor se ajuste al titular. Las categorías potenciales son las siguientes (una opción por línea):"
    OPTIONS = "\n    ".join(LABEL2TEXT.values())  # NOTA: los cuatro espacios son necesarios para el formato de textwrap.dedent()
    # Estándar sin ejemplos previos
    PROMPT_ZEROSHOT = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Titular: {{text}}
    Respuesta (por favor responda solo con una opción):""")
    # Plantilla con pocos ejemplos
    FEWSHOT_TEMPLATE = textwrap.dedent(f"""\
    {INSTRUCTION}
    {OPTIONS}

    Aquí hay algunos casos de ejemplo.

    {{{{fewshot_text}}}}

    Ahora responde el siguiente caso.

    Titular: {{text}}
    Respuesta:""")
    # Plantilla de pregunta
    QUESTION_TEMPLATE = textwrap.dedent(f"""\
    Titular: {{text}}""")
    # Plantilla de respuesta
    SHOT_TEMPLATE = textwrap.dedent(f"""\
    {{question}}
    Respuesta: {{answer}}""")
    # Plantilla para analizar las salidas para mapear al espacio de etiquetas
    PROMPT_PARSE = textwrap.dedent(f"""\
    Salida del modelo: {{model_output}}

    Convierte la salida del modelo en una de las siguientes opciones (una opción por línea):
    {OPTIONS}

    Respuesta (por favor responda solo con una opción):""")

if __name__ == "__main__":
    bench = MultiFinESBench()
    for time_step, row in enumerate(bench.get_dataset()):
        x = bench.get_input(row)
        print(x["prompt_zeroshot"], end="\n\n\n==========\n")
        print(x["prompt_cot"], end="\n\n\n==========\n")
        print(x["prompt_fewshot"], end="\n\n\n==========\n")
        if time_step == 0:
            break
