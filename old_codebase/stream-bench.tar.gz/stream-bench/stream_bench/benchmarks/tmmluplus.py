import re
import evaluate
from colorama import Fore, Style
from stream_bench.benchmarks.base import Bench

def match_response_choices(response: str, converter = None):
    pattern = [
            r"([A-D]). ",
            r"([A-D]).",
            r"答案: ([A-D]) ",
            r"答案：([A-D])",
            r"正確的答案應該是:.*?\b([A-D])\b",
            r"正確的選項應為:.*?\b([A-D])\b",
            r"所以答案為([A-D])",
            r"答案: ([A-D]) ",
            r"答案為\s?([A-D])",
            r"所以下列方程式的解是([A-D])",
            r"选([A-D])",
            r"选项([A-D])",
            r"^選([A-D])",
            r"^選項([A-D])",
            r"答案是\s?選?項?\s?([A-D])",
            r"答案為\s?選?項?\s?([A-D])",
            r"答案應為\s?選?項?\s?([A-D])",
            r"答案为\s?选?项?\s?([A-D])",
            r"答案应为\s?选?项?\s?([A-D])",
            r"答案選\s?選?項?\s?([A-D])",
            r"答案选\s?选?项?\s?([A-D])",
            r"答案是:\s?選?項?\s?([A-D])",
            r"答案應該是:\s?選?項?\s?([A-D])",
            r"答案应该是:\s?选?项?\s?([A-D])",
            r"正確的一項是\s?([A-D])",
            r"正确的一项是\s?([A-D])",
            r"答案為:\s?選?項?\s?([A-D])",
            r"答案應為:\s?選?項?\s?([A-D])",
            r"答案:\s?選?項?\s?([A-D])",
            r"答案是\s?选?项?\s?([A-D])",
            r"答案为\s?选?项?\s?([A-D])",
            r"答案应为\s?选?项?\s?([A-D])",
            r"答案选\s?选?项?\s?([A-D])",
            r"答案是:\s?选?项?\s?([A-D])",
            r"答案应该是:\s?选?项?\s?([A-D])",
            r"正确的一项是\s?([A-D])",
            r"答案为:\s?选?项?\s?([A-D])",
            r"答案应为:\s?选?项?\s?([A-D])",
            r"答案:\s?选?项?\s?([A-D])",
            r"答案是：\s?选?项?\s?([A-D])",
            r"答案应该是：\s?选?项?\s?([A-D])",
            r"答案为：\s?选?项?\s?([A-D])",
            r"答案应为：\s?选?项?\s?([A-D])",
            r"答案：\s?选?项?\s?([A-D])",
        ]
    ans_list = []
    if response[0] in ["A", "B", "C", "D"]:
        ans_list.append(response[0])
    for p in pattern:
        if converter is not None: # for backward compatibility
            p = converter.convert(p)
        if len(ans_list) == 0:
            ans_list = re.findall(p, response)
        else:
            break
    return ans_list

TRADITIONAL_COT = [
    r"答案為(.+?)",
    r"選項(.+?)是正確的",
    r"因此，選項(.+?)",
    r"答案是(.+?)",
]
SIMPLIFIED_COT = [
    r"答案为(.+?)",
    r"选项(.+?)是正确的",
    r"因此，选项(.+?)",
    r"答案是(.+?)"
]
def cot_match_response_choice(response_str: str, is_simplified=False):
    ans_list = re.findall(r"答案是(.+?)。", response_str)
    prompt_choices = TRADITIONAL_COT
    if is_simplified:
        prompt_choices = SIMPLIFIED_COT
    for prompt_regex in prompt_choices:
        ans_list = re.findall(prompt_regex, response_str)
        if len(ans_list) != 0:
            return ans_list
    # no answer found
    return []

class TMMLUPlus(Bench):

    CHOICES = ['A', 'B', 'C', 'D']
    CHOICES2IDX = {'A': 0, 'B': 1, 'C': 2, 'D': 3, '': 4}
    MAJOR_TOPICS = ['STEM', 'humanities', 'social sciences', 'other']
    TOPICS2MAJOR = {'computer_science': 'STEM', 'financial_analysis': 'other', 'business_management': 'other', 'anti_money_laundering': 'humanities', 'management_accounting': 'other', 'introduction_to_law': 'humanities', 'engineering_math': 'STEM', 'culinary_skills': 'other', 'chinese_language_and_literature': 'social sciences', 'official_document_management': 'other', 'finance_banking': 'other', 'taiwanese_hokkien': 'social sciences', 'administrative_law': 'humanities', 'nautical_science': 'other', 'agriculture': 'other', 'junior_math_exam': 'STEM', 'fire_science': 'other', 'tve_design': 'other', 'education_(profession_level)': 'social sciences', 'trade': 'other', 'veterinary_pathology': 'other', 'economics': 'social sciences', 'technical': 'other', 'occupational_therapy_for_psychological_disorders': 'social sciences', 'organic_chemistry': 'STEM', 'auditing': 'other', 'music': 'other', 'educational_psychology': 'social sciences', 'insurance_studies': 'other', 'junior_science_exam': 'STEM', 'physical_education': 'social sciences', 'general_principles_of_law': 'humanities', 'accounting': 'other', 'junior_chinese_exam': 'social sciences', 'linear_algebra': 'STEM', 'three_principles_of_people': 'social sciences', 'geography_of_taiwan': 'social sciences', 'national_protection': 'social sciences', 'taxation': 'humanities', 'pharmacology': 'other', 'tve_chinese_language': 'social sciences', 'optometry': 'other', 'real_estate': 'other', 'tve_natural_sciences': 'STEM', 'basic_medical_science': 'STEM', 'statistics_and_machine_learning': 'STEM', 'politic_science': 'social sciences', 'human_behavior': 'social sciences', 'junior_social_studies': 'other', 'trust_practice': 'humanities', 'education': 'social sciences', 'macroeconomics': 'social sciences', 'tve_mathematics': 'STEM', 'pharmacy': 'STEM', 'traditional_chinese_medicine_clinical_medicine': 'other', 'secondary_physics': 'STEM', 'jce_humanities': 'humanities', 'veterinary_pharmacology': 'other'}
    SUBJECTS = ['junior_math_exam', 'politic_science', 'computer_science', 'secondary_physics', 'macroeconomics', 'statistics_and_machine_learning', 'taiwanese_hokkien', 'general_principles_of_law', 'financial_analysis', 'economics', 'chinese_language_and_literature', 'human_behavior', 'real_estate', 'optometry', 'music', 'accounting', 'linear_algebra', 'national_protection', 'nautical_science', 'management_accounting', 'junior_science_exam', 'junior_social_studies', 'taxation', 'educational_psychology', 'culinary_skills', 'auditing', 'official_document_management', 'jce_humanities', 'tve_natural_sciences', 'agriculture', 'three_principles_of_people', 'education', 'administrative_law', 'anti_money_laundering', 'pharmacology', 'physical_education', 'introduction_to_law', 'occupational_therapy_for_psychological_disorders', 'tve_mathematics', 'trade', 'organic_chemistry', 'geography_of_taiwan', 'trust_practice', 'insurance_studies', 'veterinary_pharmacology', 'finance_banking', 'technical', 'education_(profession_level)', 'fire_science', 'traditional_chinese_medicine_clinical_medicine', 'pharmacy', 'business_management', 'basic_medical_science', 'engineering_math', 'veterinary_pathology', 'tve_design', 'tve_chinese_language', 'junior_chinese_exam']
    DATASET_PATH = "appier-ai-research/tmmluplus_timeline_aggregated"

    def __init__(self, split='test', seed=0, prompts={}, feedback='no_user_feedback', agent=None, **kwargs):
        super().__init__({})
        self.split = split
        self.seed = seed
        self.agent = agent
        self.feedback = feedback
        self.prompts = prompts
        self.agent_callback = None
        self.predictions = { topic: [] for topic in self.SUBJECTS }
        self.references = {topic : [] for topic in self.SUBJECTS}
        if hasattr(agent, 'retrieve_experience'):
            self.agent_callback = agent.retrieve_experience

    def get_dataset(self):
        return self.dataset[self.split]

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, dict]:
        if self.feedback == "no_user_feedback":
            return False, {"feedback_msg" : "None" }
        elif self.feedback == "ground_truth":
            # hmm
            output = self.get_input(row)['prompt'].rstrip()
            output += ' '+row['answer']
            return True, {"feedback_msg" : output }
        else:
            raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        outputs = { k:v for k, v in row.items() }
        subject = row['name']
        prompt = f"你是一位專業的中文AI助理，以下是關於{subject}考試單選題，請直接選出正確的答案。\n"
        prompt += row['question']+'\n'
        for choice in self.CHOICES:
            term = row[choice]
            prompt += f'\n{choice}. {term}'
        prompt += "\n答案: "
        if self.agent_callback is not None:
            feedback = self.agent_callback(row)
            if len(feedback):
                prompt = "參考資料:\n"+ feedback + "\n\n"+ prompt

        outputs['prompt'] = prompt
        return outputs

    def get_output(self, row: dict):
        return {'answer': row['answer'], 'name': row['name'], 'year': row['year'], "label": row['answer']}

    def get_metrics(self):
        accuracy = evaluate.load("accuracy")
        metric = accuracy.compute(predictions=self.predictions,
                                       references=self.references)
        return metric

    def postprocess_generation(self, res: str, idx) -> int:
        """Parse the LLM's response into the label."""
        ans_list = match_response_choices(res, None)
        if len(ans_list) == 0:
            return ''
        return ans_list[0]

    def process_results(self, generations, answers_dict, return_details=False, simulate_env=False, **kwargs):
        """Takes the list of LM generations and evaluates them against ground truth references,
        returning the metric for the generations.
        :param generations: list(list(str))
            list of lists containing generations
        :param labels: original labels
            list of str containing refrences
        """
        accuracy = evaluate.load("accuracy")
        answer = answers_dict['answer']
        subject = answers_dict['name']
        correct = generations == answer
        if not simulate_env:
            self.n_correct += correct
            self.predictions[subject].append(self.CHOICES2IDX[generations])
            self.references[subject].append(self.CHOICES2IDX[answer])

        major2scores = { major: 0 for major in self.MAJOR_TOPICS }
        for subject in self.SUBJECTS:
            major = self.TOPICS2MAJOR[subject]
            if len(self.references[subject]):
                rolling_acc = accuracy.compute(predictions=self.predictions[subject],
                                       references=self.references[subject])["accuracy"]
                major2scores[major] = rolling_acc

        if return_details:
            return {
                'year': answers_dict['year'],
                'correct': correct,
                'n_correct': self.n_correct,
                'rolling_acc': sum(major2scores.values())/len(major2scores),
                **major2scores
            }
        return correct