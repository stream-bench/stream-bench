import os
import json
os.environ["HF_ALLOW_CODE_EVAL"] = "1"
from streaming.llms.gemini_dev import GeminiDev
from streaming.humaneval.pipeline import create_task, create_task_streaming

if __name__ == "__main__":
    agent = GeminiDev()
    top_k = [1]
    eval_task = create_task_streaming(True, 'instruct')(k=top_k)
    generations = []
    references = []

    for idx, row in enumerate(eval_task.get_dataset()):
        prompt = eval_task.get_prompt(row)
        reference_solution = eval_task.get_reference(row)
        answers = []
        raw_answers = []
        for _ in range(max(top_k)):
            answer = agent(prompt)
            processed_answer = eval_task.postprocess_generation(answer, idx)
            answers.append(processed_answer)
            raw_answers.append(answer)
            if 'error:' in answer:
                break
        pass_rate, answer_res = eval_task.process_results([answers], [eval_task.get_reference(row)], return_details=True)
        # for idx, answer in enumerate(answers):
        #     answer_res[idx]['prompt'] = answer
        print(answer_res, pass_rate)

        results = {}
        for key, value in pass_rate.items():
            results[key] = value
        results['answers'] = answers
        results['raw_answers'] = raw_answers
        for key, value in dict(row).items():
            results[key] = value

        with open('gemini_baseline_final.jsonl', 'a') as fout:
            fout.write(json.dumps(results)+'\n')