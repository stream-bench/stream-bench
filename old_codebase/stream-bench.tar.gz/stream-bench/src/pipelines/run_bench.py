import yaml
import wandb
from pathlib import Path
from argparse import ArgumentParser, Namespace

from .utils import get_agent, get_bench

def setup_args() -> Namespace:
    parser = ArgumentParser()

    parser.add_argument(
        "--agent_cfg",
        type=Path,
        required=True,
        help="Path to the agent's config yaml file"
    )
    parser.add_argument(
        "--bench_cfg",
        type=Path,
        required=True,
        help="Path to the benchmark's config yaml file."
    )
    parser.add_argument(
        "--use_wandb",
        action="store_true",
        help="Whether to use wandb for experiment tracking."
    )
    parser.add_argument(
        "--project",
        type=str,
        default=None,
        help="Project name for wandb"
    )
    parser.add_argument(
        "--entity",
        type=str,
        default=None,
        help="Team name for wandb"
    )

    return parser.parse_args()

if __name__ == "__main__":
    args = setup_args()
    agent_cfg = yaml.safe_load(args.agent_cfg.read_text())
    bench_cfg = yaml.safe_load(args.bench_cfg.read_text())
    agent = get_agent(**agent_cfg)
    bench = get_bench(**bench_cfg)
    if args.use_wandb:
        wandb.init(
            project=args.project,
            entity=args.entity,
            config=agent_cfg
        )
        bench.enable_wandb()
        metrics = bench.evaluate(agent)
        wandb.finish()
    else:
        metrics = bench.evaluate(agent)

    print(metrics)
    print(type(metrics))
