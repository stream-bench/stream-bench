from src.agents import (
    Agent,
    ANLIAgent
)
from src.benchmarks import (
    Bench,
    ANLIBench
)

def get_agent(agent_name: str, **kwargs) -> Agent:
    if agent_name == "ANLIAgent":
        return ANLIAgent(config=kwargs)
    raise ValueError(f"There is not an agent named {agent_name}.")

def get_bench(bench_name: str, **kwargs) -> Bench:
    if bench_name == "ANLIBench":
        return ANLIBench(config=kwargs)
    else:
        raise ValueError(f"There is not a benchmark named {bench_name}.")
