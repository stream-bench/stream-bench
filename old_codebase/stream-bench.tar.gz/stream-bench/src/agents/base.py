from abc import ABC, abstractmethod
from typing import Any, Union

class Agent(ABC):
    """Contains LLM(s), RAG, and prompts

    Q: How to incorporate different LLMs?
    """

    def __init__(self, config: dict):
        raise NotImplementedError

    def __call__(self, x: Union[str, dict]) -> str:
        """Inference call."""
        raise NotImplementedError

    def update(self, has_feedback: bool, feedback: str) -> None:
        # NOTE: how to automatically determine what to do with feedback?
        raise NotImplementedError

    # Methods for making prompts

# NOTE: Necessary?
class SingleAgent(Agent):
    pass

class MultiAgent(Agent):
    pass
