from src.llms import GeminiDev

def get_llm(series: str, model_name: str):
    if series == "GeminiDev":
        return GeminiDev(model_name)
    raise ValueError(f"There is not an llm series {series}.")
