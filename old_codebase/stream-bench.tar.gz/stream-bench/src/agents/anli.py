from colorama import Fore, Style
from .base import Agent
from .utils import get_llm

class ANLIAgent(Agent):
    LABEL2TEXT = {
        0: "entailment",
        1: "neutral",
        2: "contradiction"
    }
    TEXT2LABEL = {v: k for k, v in LABEL2TEXT.items()}

    def __init__(self, config: dict):
        self.llm_config = config["llm"]
        self.llm = get_llm(series=self.llm_config["series"], model_name=self.llm_config["model_name"])
        self.prompts = config["prompts"]
        self.rag = None  # TODO

    def __call__(self, x: dict) -> str:
        prompt = self.prompts["inference"].format(premise=x["premise"], hypothesis=x["hypothesis"])
        res = self.llm(prompt, max_tokens=self.llm_config["max_tokens"], temperature=self.llm_config["temperature"])
        prediction = self.parse_response(res)
        return prediction
            
    def update(self, has_feedback: bool, feedback: str) -> None:
        if has_feedback:
            raise NotImplementedError
        pass

    def parse_response(self, res: str) -> int:
        """Parse the LLM's response into the label."""
        try:
            prediction = self.TEXT2LABEL[res.lower().strip()]
        except KeyError:
            print(Fore.YELLOW + f"The response {res} cannot be mapped to a label directly. Trying to convert..." + Style.RESET_ALL)
            prompt = self.prompts["parse_to_label"].format(response=res)
            new_res = self.llm(prompt, max_tokens=self.llm_config["max_tokens"], temperature=self.llm_config["temperature"])
            print(Fore.BLUE + f"Response after conversion: {new_res}")
            prediction = self.TEXT2LABEL[new_res.lower().strip()]
        return prediction
