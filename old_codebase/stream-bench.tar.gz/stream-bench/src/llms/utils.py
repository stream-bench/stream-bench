import time
import logging
import urllib.request

import openai
import anthropic
import google.api_core.exceptions

def retry_with_exponential_backoff(
    func,
    initial_delay: float = 0.25,
    exponential_base: float = 2,
    max_retries: int = 5,
    errors: tuple = (
        openai.RateLimitError, openai.APIError,
        google.api_core.exceptions.ResourceExhausted, google.api_core.exceptions.ServiceUnavailable, google.api_core.exceptions.GoogleAPIError,
        anthropic.BadRequestError, anthropic.InternalServerError, anthropic.RateLimitError,
        urllib.error.HTTPError, urllib.error.URLError,
        ValueError
    ),
):
    """Retry a function with exponential backoff."""
    def wrapper(*args, **kwargs):
        # Initialize variables
        num_retries = 0
        delay = initial_delay
        # Loop until a successful response or max_retries is hit or an exception is raised
        while True:
            try:
                return func(*args, **kwargs)
            # Retry on specific errors
            except errors as e:
                # Increment retries
                num_retries += 1
                # Check if max retries has been reached
                if isinstance(e, ValueError) or (num_retries > max_retries):
                    logging.error(f"ValueError / Maximum number of retries ({max_retries}) exceeded.")
                    result = 'error:{}'.format(e)
                    return result
                # Sleep for the delay
                logging.error(f"Error encountered ({e}). Retry ({num_retries}) after {delay} seconds...")
                time.sleep(delay)
                # Increment the delay
                delay *= exponential_base
            # Raise exceptions for any errors not specified
            except Exception as e:
                raise e
    return wrapper
