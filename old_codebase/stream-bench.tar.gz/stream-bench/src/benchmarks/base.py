from abc import ABC, abstractmethod
from typing import Union
from datasets import load_dataset

from src.agents.base import Agent

class Bench(ABC):
    """Associated with corresponding Dataset, Feedback, and Metrics"""
    DATASET_PATH: str = None
    DATASET_NAME: str = None

    def __init__(self, config: dict):
        self.config = config
        self.dataset = load_dataset(self.DATASET_PATH, self.DATASET_NAME)
        self.use_wandb = False

    def enable_wandb(self) -> None:
        self.use_wandb = True

    @abstractmethod
    def evaluate(self, agent: Agent):
        raise NotImplementedError

    @abstractmethod
    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> Union[bool, str]:
        """Give feedback according to benchmark configurations.

        1. No feedback
        2. Weak feedback (True: correct, False: incorrect)
        3. Strong feedback (Ground truth string)
        """
        raise NotImplementedError

    @abstractmethod
    def get_input(self, row: dict) -> Union[str, dict]:
        raise NotImplementedError
