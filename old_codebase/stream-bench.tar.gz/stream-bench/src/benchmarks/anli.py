import wandb
import evaluate
from tqdm import tqdm

from .base import Agent
from src.benchmarks.base import Bench

class ANLIBench(Bench):
    DATASET_PATH = "facebook/anli"
    DATASET_NAME = ""

    def __init__(self, config: dict):
        super().__init__(config)
        print("Finishing loading ANLI dataset")  # XXX
        self.split = self.config["split"]
        self.seed = self.config["seed"]

    def evaluate(self, agent: Agent) -> dict:
        # NOTE: currently use a single split and shuffle only one time
        dataset = self.dataset[self.split].shuffle(seed=self.seed)
        ncorrect = 0
        accuracy = evaluate.load("accuracy")
        predictions, references = list(), list()
        for time_step, row in enumerate(tqdm(dataset, dynamic_ncols=True)):
            x = self.get_input(row)  # remove ground truth related information
            model_output = agent(x)
            has_feedback, feedback = self.give_feedback(model_output, row)
            agent.update(has_feedback, feedback)
            ncorrect += (model_output == row["label"])
            predictions.append(model_output)
            references.append(row["label"])
            rolling_acc = accuracy.compute(predictions=predictions, references=references)["accuracy"]
            if self.use_wandb:
                wandb.log(data={"correct_count": ncorrect, "rolling_acc": rolling_acc})
        return accuracy.compute(predictions=predictions, references=references)

    def give_feedback(self, model_output: str, row: dict, res: dict = None) -> tuple[bool, str]:
        if self.config["feedback"] == "no_user_feedback":
            return False, "None"
        else:
            raise NotImplementedError

    def get_input(self, row: dict) -> dict:
        columns = ["uid", "premise", "hypothesis"]
        return {column: row[column] for column in columns}